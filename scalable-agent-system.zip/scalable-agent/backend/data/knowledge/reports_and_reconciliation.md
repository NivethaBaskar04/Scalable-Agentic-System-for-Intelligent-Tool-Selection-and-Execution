# Reports and Reconciliation

Sales reports aggregate all captured payments (and exclude authorizations
that were never captured) over a given period. Transaction history is the
line-item detail behind a report: every sale, refund, and payout appears
as its own entry with a timestamp.

## Payout reports
A payout report summarizes funds actually transferred out of the merchant
account to their bank, which can lag several days behind the underlying
sales due to a settlement/holding period.

## Reconciliation tips
- Sales reports and transaction history should always sum to the same
  total for a given period; a mismatch usually indicates a report caching
  issue or a timezone boundary difference.
- Disputes and chargebacks are typically excluded from "sales volume" but
  shown separately as a deduction.
