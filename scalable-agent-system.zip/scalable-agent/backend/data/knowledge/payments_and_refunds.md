# Payments and Refunds

A payment typically has two phases: **authorization** (funds are reserved
on the buyer's account) and **capture** (funds are actually transferred to
the merchant). Some integrations capture immediately; others hold an
authorization for a period (commonly 3-29 days) before it must be captured
or it expires.

## Refunds
A captured payment can be refunded in full or in part. Partial refunds are
common for scenarios like a partial return or a shipping-fee adjustment.
Refunds typically take 3-5 business days to appear on the buyer's statement
and are not reversible once issued - a new payment would be required to
reverse a refund.

## Voids
An authorized-but-not-yet-captured payment can be voided instead of
refunded. A void releases the buyer's held funds immediately at no cost,
whereas a refund of a captured payment usually involves a small
processing delay.
