# Subscriptions

A subscription bills a customer on a recurring schedule (commonly monthly
or annually) against a fixed plan. Plans are usually tiered (e.g. basic,
pro, enterprise), each with different pricing and feature entitlements.

## Cancellation
Cancelling a subscription typically stops future billing but does not
retroactively refund the current billing period unless the merchant
explicitly issues a refund for it. Some systems distinguish between
"cancel immediately" and "cancel at period end."

## Plan changes
Upgrading mid-cycle is usually prorated - the customer is charged the
difference for the remainder of the current period. Downgrading typically
takes effect at the next renewal to avoid issuing a refund.
