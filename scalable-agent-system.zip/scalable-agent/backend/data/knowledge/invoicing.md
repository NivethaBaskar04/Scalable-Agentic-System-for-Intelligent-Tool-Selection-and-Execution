# Invoicing Guide

Invoices move through the following statuses: DRAFT -> SENT -> PAID (or
CANCELLED). A draft invoice is not visible to the customer and can be
edited freely. Once sent, the customer receives an email with a payment
link, and the invoice can no longer be edited, only cancelled or reminded.

## Reminders
If an invoice remains unpaid after the due date, a reminder can be sent.
Most systems limit reminders to avoid spamming the customer - typically no
more than one every few days.

## Partial payments
Some invoicing systems allow partial payments against an invoice; the
invoice remains in a "partially paid" state until the full amount is
collected.

## Multi-currency
Invoices can be issued in the customer's local currency. The merchant's
payout is converted to their settlement currency at the platform's
prevailing exchange rate at the time of payment.
