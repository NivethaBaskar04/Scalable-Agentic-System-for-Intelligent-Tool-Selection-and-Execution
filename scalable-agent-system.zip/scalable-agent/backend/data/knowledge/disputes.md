# How PayPal-style Disputes Work

A dispute is opened when a customer believes there is a problem with a
transaction - for example, an item was never received, was significantly
not as described, or the customer does not recognize the charge.

## Lifecycle
1. **Inquiry** - the customer raises a concern directly with the merchant
   through the platform. Most inquiries are resolved here without ever
   becoming a formal dispute.
2. **Dispute (Open)** - if the inquiry isn't resolved within the response
   window, it escalates to an open dispute. The merchant is notified and
   must respond with evidence (proof of shipment, delivery confirmation,
   correspondence, etc.) within a fixed window, usually 10 days.
3. **Claim** - if the dispute still isn't resolved, either party can escalate
   to a claim, which is decided by PayPal-style dispute resolution based on
   the evidence submitted.
4. **Resolution** - the claim is resolved in favor of the buyer or seller.
   If resolved for the buyer, funds are typically reversed (a chargeback).

## Chargebacks
A chargeback is initiated by the customer's card issuer or bank rather than
through the platform directly, and usually carries an additional fee for
the merchant regardless of outcome.

## Best practices for merchants
- Respond to every dispute before the deadline - non-response is treated as
  a forfeit.
- Keep delivery and communication records for every order.
- Use tracked shipping so proof of delivery is available immediately.
- Resolve inquiries quickly, before they escalate to formal disputes.
