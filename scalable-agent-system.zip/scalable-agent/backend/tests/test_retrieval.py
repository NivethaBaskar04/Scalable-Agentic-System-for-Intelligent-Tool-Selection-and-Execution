from app.registry.store import ToolRegistry
from app.retrieval.tfidf_retriever import TfidfRetriever
from app.domain_router import DomainRouter


def test_retriever_returns_relevant_tools():
    registry = ToolRegistry()
    retriever = TfidfRetriever(registry)
    results = retriever.retrieve("send an invoice", top_k=5)
    names = [t.tool_name for t, _ in results]
    assert "send_invoice" in names or "create_invoice" in names


def test_retriever_respects_top_k():
    registry = ToolRegistry()
    retriever = TfidfRetriever(registry)
    results = retriever.retrieve("payment refund", top_k=3)
    assert len(results) <= 3


def test_retriever_never_exceeds_registry_when_asked_more_than_exists():
    registry = ToolRegistry()
    retriever = TfidfRetriever(registry)
    results = retriever.retrieve("invoice", top_k=10_000)
    assert len(results) <= registry.count()


def test_domain_router_routes_invoice_query_to_invoices():
    registry = ToolRegistry()
    router = DomainRouter(registry)
    scores = router.route("send an invoice for $50", top_k=1)
    assert scores
    assert scores[0][0] == "invoices"


def test_domain_router_routes_dispute_query_to_disputes():
    registry = ToolRegistry()
    router = DomainRouter(registry)
    scores = router.route("is there an open dispute", top_k=1)
    assert scores
    assert scores[0][0] == "disputes"
