import pytest

from app.registry.store import ToolRegistry
from app.memory.state import StateStore
from app.executor.engine import ExecutionEngine
from app.registry.schema import ExecutionPlan, ExecutionStep


@pytest.mark.asyncio
async def test_create_invoice_executes_successfully(tmp_path):
    registry = ToolRegistry()
    state = StateStore(db_path=str(tmp_path / "state.sqlite3"))
    engine = ExecutionEngine(registry, state)

    plan = ExecutionPlan(goal="test", steps=[
        ExecutionStep(tool="create_invoice", parameters={"amount": 50, "customer_name": "Test User"}),
    ])
    trace = await engine.execute_plan(plan, "test-exec-1", "invoices", 5, 100)
    assert trace.status == "success"
    assert trace.steps[0].success
    assert "invoice_id" in trace.steps[0].result


@pytest.mark.asyncio
async def test_multi_step_plan_passes_output_between_steps(tmp_path):
    registry = ToolRegistry()
    state = StateStore(db_path=str(tmp_path / "state.sqlite3"))
    engine = ExecutionEngine(registry, state)

    plan = ExecutionPlan(goal="test", steps=[
        ExecutionStep(tool="create_invoice", parameters={"amount": 100}),
        ExecutionStep(tool="send_invoice", parameters={"invoice_id": "$previous_result.invoice_id"}),
    ])
    trace = await engine.execute_plan(plan, "test-exec-2", "invoices", 5, 100)
    assert trace.status == "success"
    assert len(trace.steps) == 2
    assert trace.steps[1].parameters["invoice_id"] == trace.steps[0].result["invoice_id"]


@pytest.mark.asyncio
async def test_plan_stops_on_missing_required_parameter(tmp_path):
    registry = ToolRegistry()
    state = StateStore(db_path=str(tmp_path / "state.sqlite3"))
    engine = ExecutionEngine(registry, state)

    plan = ExecutionPlan(goal="test", steps=[
        ExecutionStep(tool="create_invoice", parameters={}),  # missing required 'amount'
    ])
    trace = await engine.execute_plan(plan, "test-exec-3", "invoices", 5, 100)
    assert trace.status == "needs_clarification"


@pytest.mark.asyncio
async def test_plan_refuses_invented_tool(tmp_path):
    registry = ToolRegistry()
    state = StateStore(db_path=str(tmp_path / "state.sqlite3"))
    engine = ExecutionEngine(registry, state)

    plan = ExecutionPlan(goal="test", steps=[
        ExecutionStep(tool="delete_entire_database", parameters={}),
    ])
    trace = await engine.execute_plan(plan, "test-exec-4", "unknown", 0, 100)
    assert trace.status == "failed"
    assert not trace.steps[0].success


@pytest.mark.asyncio
async def test_get_disputes_reflects_seeded_data(tmp_path):
    registry = ToolRegistry()
    state = StateStore(db_path=str(tmp_path / "state.sqlite3"))
    engine = ExecutionEngine(registry, state)

    plan = ExecutionPlan(goal="test", steps=[
        ExecutionStep(tool="get_disputes", parameters={"customer_name": "user_123"}),
    ])
    trace = await engine.execute_plan(plan, "test-exec-5", "disputes", 5, 100)
    assert trace.status == "success"
    assert len(trace.steps[0].result["disputes"]) >= 1
