from app.registry.store import ToolRegistry
from app.validation.validator import validate_parameters


def test_missing_required_parameter_detected():
    registry = ToolRegistry()
    tool = registry.get_by_name("create_invoice")
    result = validate_parameters(tool, {})
    assert not result.valid
    assert "amount" in result.missing_required


def test_valid_parameters_pass():
    registry = ToolRegistry()
    tool = registry.get_by_name("create_invoice")
    result = validate_parameters(tool, {"amount": 50})
    assert result.valid


def test_enum_violation_detected():
    registry = ToolRegistry()
    tool = registry.get_by_name("create_invoice")
    result = validate_parameters(tool, {"amount": 50, "currency": "XYZ"})
    assert not result.valid
    assert result.enum_errors


def test_type_violation_detected():
    registry = ToolRegistry()
    tool = registry.get_by_name("create_invoice")
    result = validate_parameters(tool, {"amount": "not-a-number"})
    assert not result.valid
    assert result.type_errors


def test_range_violation_detected():
    registry = ToolRegistry()
    tool = registry.get_by_name("create_invoice")
    result = validate_parameters(tool, {"amount": -5})
    assert not result.valid
    assert result.range_errors
