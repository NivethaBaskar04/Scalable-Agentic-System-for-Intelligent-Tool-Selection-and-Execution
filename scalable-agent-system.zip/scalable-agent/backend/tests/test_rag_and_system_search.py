from app.rag.rag_engine import RagEngine
from app.registry.store import ToolRegistry
from app.memory.state import StateStore
from app.system_search.search import system_search


def test_rag_search_finds_dispute_content():
    engine = RagEngine()
    results = engine.search("how do disputes work", top_k=3)
    assert len(results) > 0
    assert any("dispute" in r["text"].lower() or "dispute" in r["source"].lower() for r in results)


def test_rag_search_returns_score_and_source():
    engine = RagEngine()
    results = engine.search("refund process", top_k=3)
    for r in results:
        assert "source" in r
        assert "similarity_score" in r
        assert 0 <= r["similarity_score"] <= 1


def test_system_search_tool_count(tmp_path):
    registry = ToolRegistry()
    state = StateStore(db_path=str(tmp_path / "state.sqlite3"))
    result = system_search("how many tools are registered?", registry, state)
    assert result["answer_type"] == "tool_count"
    assert result["total_tools"] == registry.count()


def test_system_search_tools_for_topic(tmp_path):
    registry = ToolRegistry()
    state = StateStore(db_path=str(tmp_path / "state.sqlite3"))
    result = system_search("what tools manage invoices", registry, state)
    assert result["answer_type"] == "tools_for_topic"
    assert result["count"] >= 1
