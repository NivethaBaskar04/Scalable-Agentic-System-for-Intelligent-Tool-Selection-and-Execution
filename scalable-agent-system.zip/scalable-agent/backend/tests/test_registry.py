from app.registry.store import ToolRegistry
from app.config import TOOLS_FILE


def test_registry_loads_tools():
    registry = ToolRegistry()
    assert registry.count() > 0


def test_registry_domains_nonempty():
    registry = ToolRegistry()
    assert len(registry.domains()) > 0


def test_registry_get_by_name():
    registry = ToolRegistry()
    tool = registry.get_by_name("create_invoice")
    assert tool is not None
    assert tool.domain == "invoices"


def test_registry_by_domain():
    registry = ToolRegistry()
    invoice_tools = registry.by_domain("invoices")
    assert all(t.domain == "invoices" for t in invoice_tools)
    assert len(invoice_tools) > 0


def test_required_and_optional_params():
    registry = ToolRegistry()
    tool = registry.get_by_name("create_invoice")
    assert "amount" in tool.required_params()
    assert "customer_name" in tool.optional_params()
