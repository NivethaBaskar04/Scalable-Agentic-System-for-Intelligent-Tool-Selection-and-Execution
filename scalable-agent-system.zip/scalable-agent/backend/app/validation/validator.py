"""
Parameter Validator.

Before any tool executes, its proposed parameters are checked against the
tool's declared input_schema: required fields, types, enums, and ranges.
Missing required parameters are surfaced as a clarification request rather
than guessed - the agent must ask the user, never hallucinate a value.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List

from app.registry.schema import Tool


@dataclass
class ValidationResult:
    valid: bool
    missing_required: List[str] = field(default_factory=list)
    type_errors: List[str] = field(default_factory=list)
    enum_errors: List[str] = field(default_factory=list)
    range_errors: List[str] = field(default_factory=list)

    @property
    def errors(self) -> List[str]:
        return self.missing_required + self.type_errors + self.enum_errors + self.range_errors

    def clarification_message(self) -> str:
        if self.missing_required:
            fields = ", ".join(self.missing_required)
            return f"I need a bit more information before I can do that: {fields}."
        return "; ".join(self.errors)


def _check_type(value: Any, expected: str) -> bool:
    if expected == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "string":
        return isinstance(value, str)
    return True


def validate_parameters(tool: Tool, parameters: Dict[str, Any]) -> ValidationResult:
    result = ValidationResult(valid=True)

    for p in tool.input_schema:
        value = parameters.get(p.name)

        if p.required and (value is None or value == ""):
            result.missing_required.append(p.name)
            continue

        if value is None:
            continue  # optional and absent, fine

        if not _check_type(value, p.type):
            result.type_errors.append(f"'{p.name}' must be of type {p.type}")

        if p.enum and value not in p.enum:
            result.enum_errors.append(f"'{p.name}' must be one of {p.enum}, got '{value}'")

        if p.minimum is not None and isinstance(value, (int, float)) and value < p.minimum:
            result.range_errors.append(f"'{p.name}' must be >= {p.minimum}")

        if p.maximum is not None and isinstance(value, (int, float)) and value > p.maximum:
            result.range_errors.append(f"'{p.name}' must be <= {p.maximum}")

    result.valid = not (result.missing_required or result.type_errors or result.enum_errors or result.range_errors)
    return result
