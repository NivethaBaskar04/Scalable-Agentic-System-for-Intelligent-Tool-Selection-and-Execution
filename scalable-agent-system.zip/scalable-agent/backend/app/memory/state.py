"""
Persistent Agent State.

Uses SQLite via plain sqlite3 (no ORM needed for this shape) so it's trivial
to inspect (`sqlite3 data/agent_state.sqlite3`) and trivial to later swap for
PostgreSQL: every method here is a small, self-contained SQL statement, so a
PostgreSQL/Redis-backed StateStore subclass could implement the same
interface without touching any caller.
"""
from __future__ import annotations
import json
import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from typing import Any, Dict, List, Optional

from app.config import AGENT_DB

SCHEMA = """
CREATE TABLE IF NOT EXISTS conversations (
    conversation_id TEXT PRIMARY KEY,
    user_id TEXT,
    created_at REAL
);

CREATE TABLE IF NOT EXISTS executions (
    execution_id TEXT PRIMARY KEY,
    conversation_id TEXT,
    user_query TEXT,
    domain TEXT,
    plan_json TEXT,
    status TEXT,
    error TEXT,
    created_at REAL,
    completed_at REAL,
    latency_ms REAL,
    tools_retrieved INTEGER,
    total_tools_available INTEGER
);

CREATE TABLE IF NOT EXISTS step_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    execution_id TEXT,
    tool_id TEXT,
    parameters_json TEXT,
    result_json TEXT,
    success INTEGER,
    error TEXT,
    retries INTEGER,
    latency_ms REAL,
    created_at REAL
);

CREATE TABLE IF NOT EXISTS tool_stats (
    tool_id TEXT PRIMARY KEY,
    success_count INTEGER DEFAULT 0,
    failure_count INTEGER DEFAULT 0,
    reliability REAL DEFAULT 0.8
);
"""


class StateStore:
    def __init__(self, db_path=None):
        self.db_path = str(db_path or AGENT_DB)
        self._lock = threading.RLock()
        self._init_db()

    @contextmanager
    def _conn(self):
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def _init_db(self):
        with self._lock, self._conn() as conn:
            conn.executescript(SCHEMA)

    # ---------------- Conversations ----------------
    def ensure_conversation(self, conversation_id: str, user_id: str = "demo_user") -> None:
        with self._lock, self._conn() as conn:
            conn.execute(
                "INSERT OR IGNORE INTO conversations (conversation_id, user_id, created_at) VALUES (?, ?, ?)",
                (conversation_id, user_id, time.time()),
            )

    # ---------------- Executions ----------------
    def start_execution(self, conversation_id: str, user_query: str, domain: str,
                         tools_retrieved: int, total_tools_available: int) -> str:
        execution_id = str(uuid.uuid4())
        with self._lock, self._conn() as conn:
            conn.execute(
                """INSERT INTO executions
                   (execution_id, conversation_id, user_query, domain, plan_json, status,
                    error, created_at, completed_at, latency_ms, tools_retrieved, total_tools_available)
                   VALUES (?, ?, ?, ?, NULL, 'running', NULL, ?, NULL, NULL, ?, ?)""",
                (execution_id, conversation_id, user_query, domain, time.time(), tools_retrieved, total_tools_available),
            )
        return execution_id

    def complete_execution(self, execution_id: str, plan: dict, status: str,
                            error: Optional[str], latency_ms: float) -> None:
        with self._lock, self._conn() as conn:
            conn.execute(
                """UPDATE executions SET plan_json=?, status=?, error=?, completed_at=?, latency_ms=?
                   WHERE execution_id=?""",
                (json.dumps(plan), status, error, time.time(), latency_ms, execution_id),
            )

    def record_step_result(self, execution_id: str, tool_id: str, parameters: dict,
                            result: Any, success: bool, error: Optional[str],
                            retries: int, latency_ms: float) -> None:
        with self._lock, self._conn() as conn:
            conn.execute(
                """INSERT INTO step_results
                   (execution_id, tool_id, parameters_json, result_json, success, error, retries, latency_ms, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (execution_id, tool_id, json.dumps(parameters), json.dumps(result, default=str),
                 1 if success else 0, error, retries, latency_ms, time.time()),
            )
            row = conn.execute("SELECT * FROM tool_stats WHERE tool_id=?", (tool_id,)).fetchone()
            if row is None:
                success_count = 1 if success else 0
                failure_count = 0 if success else 1
                conn.execute(
                    "INSERT INTO tool_stats (tool_id, success_count, failure_count, reliability) VALUES (?, ?, ?, ?)",
                    (tool_id, success_count, failure_count, 0.9 if success else 0.6),
                )
            else:
                success_count = row["success_count"] + (1 if success else 0)
                failure_count = row["failure_count"] + (0 if success else 1)
                total = success_count + failure_count
                reliability = success_count / total if total else 0.8
                conn.execute(
                    "UPDATE tool_stats SET success_count=?, failure_count=?, reliability=? WHERE tool_id=?",
                    (success_count, failure_count, reliability, tool_id),
                )

    def get_tool_success_rate(self, tool_id: str) -> float:
        with self._lock, self._conn() as conn:
            row = conn.execute("SELECT * FROM tool_stats WHERE tool_id=?", (tool_id,)).fetchone()
            if not row:
                return 0.75  # neutral prior for tools with no history yet
            total = row["success_count"] + row["failure_count"]
            return row["success_count"] / total if total else 0.75

    def get_tool_reliability(self, tool_id: str) -> float:
        with self._lock, self._conn() as conn:
            row = conn.execute("SELECT * FROM tool_stats WHERE tool_id=?", (tool_id,)).fetchone()
            return row["reliability"] if row else 0.8

    def get_execution(self, execution_id: str) -> Optional[dict]:
        with self._lock, self._conn() as conn:
            row = conn.execute("SELECT * FROM executions WHERE execution_id=?", (execution_id,)).fetchone()
            if not row:
                return None
            steps = conn.execute("SELECT * FROM step_results WHERE execution_id=? ORDER BY id", (execution_id,)).fetchall()
            d = dict(row)
            d["plan"] = json.loads(d["plan_json"]) if d["plan_json"] else None
            d["steps"] = [dict(s) for s in steps]
            for s in d["steps"]:
                s["parameters"] = json.loads(s["parameters_json"])
                s["result"] = json.loads(s["result_json"]) if s["result_json"] else None
            return d

    def list_executions(self, limit: int = 50) -> List[dict]:
        with self._lock, self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM executions ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
            return [dict(r) for r in rows]

    def recent_failures(self, limit: int = 20) -> List[dict]:
        with self._lock, self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM step_results WHERE success=0 ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
            return [dict(r) for r in rows]

    def metrics_summary(self) -> Dict[str, Any]:
        with self._lock, self._conn() as conn:
            total = conn.execute("SELECT COUNT(*) c FROM executions").fetchone()["c"]
            succeeded = conn.execute("SELECT COUNT(*) c FROM executions WHERE status='success'").fetchone()["c"]
            avg_latency = conn.execute("SELECT AVG(latency_ms) a FROM executions WHERE latency_ms IS NOT NULL").fetchone()["a"]
            avg_retrieved = conn.execute("SELECT AVG(tools_retrieved) a FROM executions").fetchone()["a"]
            return {
                "total_executions": total,
                "successful_executions": succeeded,
                "success_rate": (succeeded / total) if total else None,
                "avg_latency_ms": avg_latency,
                "avg_tools_retrieved": avg_retrieved,
            }


state_store = StateStore()
