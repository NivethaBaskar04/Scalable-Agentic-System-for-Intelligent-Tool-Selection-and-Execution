"""
Tool schema: the canonical shape of every tool in the registry, regardless
of whether it is a real mock-PayPal endpoint or an auto-generated one used
to stress-test scalability.
"""
from __future__ import annotations
from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class RiskLevel(str, Enum):
    low = "low"
    medium = "medium"
    high = "high"


class ParamSchema(BaseModel):
    """A single parameter's validation contract."""
    name: str
    type: str = "string"  # string | number | integer | boolean | enum
    required: bool = True
    description: str = ""
    enum: Optional[List[str]] = None
    minimum: Optional[float] = None
    maximum: Optional[float] = None


class Tool(BaseModel):
    tool_id: str
    tool_name: str
    description: str
    service: str
    domain: str
    operation: str  # create | get | update | delete | list | send | cancel | capture | refund | search
    method: str = "POST"
    endpoint: str
    input_schema: List[ParamSchema] = Field(default_factory=list)
    output_schema: Dict[str, str] = Field(default_factory=dict)
    required_auth: bool = True
    risk_level: RiskLevel = RiskLevel.low
    tags: List[str] = Field(default_factory=list)
    version: str = "1.0"
    dependencies: List[str] = Field(default_factory=list)  # tool_ids that logically precede this one

    def required_params(self) -> List[str]:
        return [p.name for p in self.input_schema if p.required]

    def optional_params(self) -> List[str]:
        return [p.name for p in self.input_schema if not p.required]

    def searchable_text(self) -> str:
        """The blob of text used for TF-IDF / embedding retrieval."""
        parts = [
            self.tool_name.replace("_", " "),
            self.description,
            self.domain,
            self.operation,
            self.service,
            " ".join(self.tags),
        ]
        return " ".join(parts)


class ExecutionStep(BaseModel):
    tool: str
    parameters: Dict[str, Any] = Field(default_factory=dict)


class ExecutionPlan(BaseModel):
    goal: str
    steps: List[ExecutionStep] = Field(default_factory=list)
    requires_confirmation: bool = False
    clarification_needed: Optional[str] = None
