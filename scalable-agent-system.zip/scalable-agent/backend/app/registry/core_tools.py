"""
Hand-authored "core" tools: a realistic ~55-tool PayPal-like API surface
spanning every domain named in the spec. These are the tools that are
actually wired to the mock PayPal API and can be executed end-to-end.

Auto-generated bulk tools (for scalability benchmarking to 500/1000) are
layered on top of these by scripts/generate_tools.py and are inert stubs -
they exist to prove the retrieval pipeline scales, not to be executed.
"""
from app.registry.schema import Tool, ParamSchema, RiskLevel

P = ParamSchema


def _t(**kw) -> dict:
    return kw


CORE_TOOLS = [
    # ---------------- INVOICES ----------------
    _t(tool_id="paypal.invoice.create", tool_name="create_invoice", service="paypal",
       domain="invoices", operation="create",
       description="Creates a new draft invoice for a customer with a given amount and currency.",
       method="POST", endpoint="/paypal/invoices", risk_level=RiskLevel.medium,
       tags=["invoice", "billing", "create"],
       input_schema=[
           P(name="amount", type="number", required=True, description="Invoice amount", minimum=0.01),
           P(name="customer_name", type="string", required=False, description="Name of the customer to invoice"),
           P(name="currency", type="string", required=False, description="ISO currency code", enum=["USD", "EUR", "GBP"]),
       ],
       output_schema={"invoice_id": "string", "status": "string"}),

    _t(tool_id="paypal.invoice.send", tool_name="send_invoice", service="paypal",
       domain="invoices", operation="send",
       description="Sends a previously created invoice to the customer by email.",
       method="POST", endpoint="/paypal/invoices/{invoice_id}/send", risk_level=RiskLevel.medium,
       tags=["invoice", "billing", "send"],
       input_schema=[P(name="invoice_id", type="string", required=True, description="ID of the invoice to send")],
       output_schema={"status": "string"},
       dependencies=["paypal.invoice.create"]),

    _t(tool_id="paypal.invoice.get", tool_name="get_invoice", service="paypal",
       domain="invoices", operation="get",
       description="Retrieves the details and status of an existing invoice.",
       method="GET", endpoint="/paypal/invoices/{invoice_id}", risk_level=RiskLevel.low,
       tags=["invoice", "billing", "read"],
       input_schema=[P(name="invoice_id", type="string", required=True)],
       output_schema={"invoice": "object"}),

    _t(tool_id="paypal.invoice.cancel", tool_name="cancel_invoice", service="paypal",
       domain="invoices", operation="cancel",
       description="Cancels an existing unpaid invoice.",
       method="POST", endpoint="/paypal/invoices/{invoice_id}/cancel", risk_level=RiskLevel.medium,
       tags=["invoice", "billing", "cancel"],
       input_schema=[P(name="invoice_id", type="string", required=True)],
       output_schema={"status": "string"}),

    _t(tool_id="paypal.invoice.list", tool_name="list_invoices", service="paypal",
       domain="invoices", operation="list",
       description="Lists invoices, optionally filtered by status.",
       method="GET", endpoint="/paypal/invoices", risk_level=RiskLevel.low,
       tags=["invoice", "billing", "list"],
       input_schema=[P(name="status", type="string", required=False, enum=["DRAFT", "SENT", "PAID", "CANCELLED"])],
       output_schema={"invoices": "array"}),

    _t(tool_id="paypal.invoice.remind", tool_name="send_invoice_reminder", service="paypal",
       domain="invoices", operation="send",
       description="Sends a payment reminder for an already-sent, unpaid invoice.",
       method="POST", endpoint="/paypal/invoices/{invoice_id}/remind", risk_level=RiskLevel.low,
       tags=["invoice", "billing", "reminder"],
       input_schema=[P(name="invoice_id", type="string", required=True)],
       output_schema={"status": "string"}),

    # ---------------- PAYMENTS ----------------
    _t(tool_id="paypal.payment.create", tool_name="create_payment", service="paypal",
       domain="payments", operation="create",
       description="Creates (authorizes) a new payment for a given amount.",
       method="POST", endpoint="/paypal/payments", risk_level=RiskLevel.high,
       tags=["payment", "charge", "create"],
       input_schema=[
           P(name="amount", type="number", required=True, minimum=0.01),
           P(name="currency", type="string", required=False, enum=["USD", "EUR", "GBP"]),
           P(name="customer_name", type="string", required=False),
       ],
       output_schema={"payment_id": "string", "status": "string"}),

    _t(tool_id="paypal.payment.capture", tool_name="capture_payment", service="paypal",
       domain="payments", operation="capture",
       description="Captures (settles) a previously authorized payment.",
       method="POST", endpoint="/paypal/payments/{payment_id}/capture", risk_level=RiskLevel.high,
       tags=["payment", "capture"],
       input_schema=[P(name="payment_id", type="string", required=True)],
       output_schema={"status": "string"}),

    _t(tool_id="paypal.payment.refund", tool_name="refund_payment", service="paypal",
       domain="payments", operation="refund",
       description="Refunds all or part of a captured payment.",
       method="POST", endpoint="/paypal/payments/{payment_id}/refund", risk_level=RiskLevel.high,
       tags=["payment", "refund"],
       input_schema=[
           P(name="payment_id", type="string", required=True),
           P(name="amount", type="number", required=False, minimum=0.01, description="Partial refund amount; omit for full refund"),
       ],
       output_schema={"status": "string", "refund_id": "string"}),

    _t(tool_id="paypal.payment.get", tool_name="get_payment", service="paypal",
       domain="payments", operation="get",
       description="Retrieves the details and current status of a payment.",
       method="GET", endpoint="/paypal/payments/{payment_id}", risk_level=RiskLevel.low,
       tags=["payment", "read"],
       input_schema=[P(name="payment_id", type="string", required=True)],
       output_schema={"payment": "object"}),

    _t(tool_id="paypal.payment.list", tool_name="list_payments", service="paypal",
       domain="payments", operation="list",
       description="Lists recent payments, optionally filtered by status.",
       method="GET", endpoint="/paypal/payments", risk_level=RiskLevel.low,
       tags=["payment", "list"],
       input_schema=[P(name="status", type="string", required=False, enum=["CREATED", "CAPTURED", "REFUNDED"])],
       output_schema={"payments": "array"}),

    _t(tool_id="paypal.payment.void", tool_name="void_payment", service="paypal",
       domain="payments", operation="cancel",
       description="Voids an authorized but not-yet-captured payment.",
       method="POST", endpoint="/paypal/payments/{payment_id}/void", risk_level=RiskLevel.medium,
       tags=["payment", "void", "cancel"],
       input_schema=[P(name="payment_id", type="string", required=True)],
       output_schema={"status": "string"}),

    # ---------------- CUSTOMERS ----------------
    _t(tool_id="paypal.customer.create", tool_name="create_customer", service="paypal",
       domain="customers", operation="create",
       description="Creates a new customer record.",
       method="POST", endpoint="/paypal/customers", risk_level=RiskLevel.low,
       tags=["customer", "create"],
       input_schema=[
           P(name="name", type="string", required=True),
           P(name="email", type="string", required=False),
       ],
       output_schema={"customer_id": "string"}),

    _t(tool_id="paypal.customer.get", tool_name="get_customer", service="paypal",
       domain="customers", operation="get",
       description="Retrieves a customer's profile information.",
       method="GET", endpoint="/paypal/customers/{customer_id}", risk_level=RiskLevel.low,
       tags=["customer", "read"],
       input_schema=[P(name="customer_id", type="string", required=True)],
       output_schema={"customer": "object"}),

    _t(tool_id="paypal.customer.find_by_name", tool_name="find_customer", service="paypal",
       domain="customers", operation="search",
       description="Finds a customer's ID by their name (fuzzy match).",
       method="GET", endpoint="/paypal/customers/search", risk_level=RiskLevel.low,
       tags=["customer", "search", "lookup"],
       input_schema=[P(name="name", type="string", required=True)],
       output_schema={"customer_id": "string", "name": "string"}),

    _t(tool_id="paypal.customer.update", tool_name="update_customer", service="paypal",
       domain="customers", operation="update",
       description="Updates a customer's profile fields.",
       method="PATCH", endpoint="/paypal/customers/{customer_id}", risk_level=RiskLevel.medium,
       tags=["customer", "update"],
       input_schema=[
           P(name="customer_id", type="string", required=True),
           P(name="email", type="string", required=False),
           P(name="name", type="string", required=False),
       ],
       output_schema={"status": "string"}),

    _t(tool_id="paypal.customer.delete", tool_name="delete_customer", service="paypal",
       domain="customers", operation="delete",
       description="Permanently deletes a customer record.",
       method="DELETE", endpoint="/paypal/customers/{customer_id}", risk_level=RiskLevel.high,
       tags=["customer", "delete"],
       input_schema=[P(name="customer_id", type="string", required=True)],
       output_schema={"status": "string"}),

    _t(tool_id="paypal.customer.list", tool_name="list_customers", service="paypal",
       domain="customers", operation="list",
       description="Lists all known customers.",
       method="GET", endpoint="/paypal/customers", risk_level=RiskLevel.low,
       tags=["customer", "list"],
       input_schema=[],
       output_schema={"customers": "array"}),

    # ---------------- SUBSCRIPTIONS ----------------
    _t(tool_id="paypal.subscription.create", tool_name="create_subscription", service="paypal",
       domain="subscriptions", operation="create",
       description="Creates a new recurring subscription for a customer.",
       method="POST", endpoint="/paypal/subscriptions", risk_level=RiskLevel.medium,
       tags=["subscription", "recurring", "create"],
       input_schema=[
           P(name="customer_name", type="string", required=True),
           P(name="plan", type="string", required=True, enum=["basic", "pro", "enterprise"]),
       ],
       output_schema={"subscription_id": "string"}),

    _t(tool_id="paypal.subscription.cancel", tool_name="cancel_subscription", service="paypal",
       domain="subscriptions", operation="cancel",
       description="Cancels an active subscription.",
       method="POST", endpoint="/paypal/subscriptions/{subscription_id}/cancel", risk_level=RiskLevel.medium,
       tags=["subscription", "cancel"],
       input_schema=[P(name="subscription_id", type="string", required=True)],
       output_schema={"status": "string"}),

    _t(tool_id="paypal.subscription.get", tool_name="get_subscription", service="paypal",
       domain="subscriptions", operation="get",
       description="Retrieves details and status of a subscription.",
       method="GET", endpoint="/paypal/subscriptions/{subscription_id}", risk_level=RiskLevel.low,
       tags=["subscription", "read"],
       input_schema=[P(name="subscription_id", type="string", required=True)],
       output_schema={"subscription": "object"}),

    _t(tool_id="paypal.subscription.list", tool_name="list_subscriptions", service="paypal",
       domain="subscriptions", operation="list",
       description="Lists all subscriptions, optionally by status.",
       method="GET", endpoint="/paypal/subscriptions", risk_level=RiskLevel.low,
       tags=["subscription", "list"],
       input_schema=[P(name="status", type="string", required=False, enum=["ACTIVE", "CANCELLED"])],
       output_schema={"subscriptions": "array"}),

    _t(tool_id="paypal.subscription.update_plan", tool_name="update_subscription_plan", service="paypal",
       domain="subscriptions", operation="update",
       description="Changes the plan tier of an active subscription.",
       method="PATCH", endpoint="/paypal/subscriptions/{subscription_id}", risk_level=RiskLevel.medium,
       tags=["subscription", "update", "plan"],
       input_schema=[
           P(name="subscription_id", type="string", required=True),
           P(name="plan", type="string", required=True, enum=["basic", "pro", "enterprise"]),
       ],
       output_schema={"status": "string"}),

    # ---------------- DISPUTES ----------------
    _t(tool_id="paypal.dispute.create", tool_name="create_dispute", service="paypal",
       domain="disputes", operation="create",
       description="Files a new dispute against a payment on behalf of a customer.",
       method="POST", endpoint="/paypal/disputes", risk_level=RiskLevel.high,
       tags=["dispute", "chargeback", "create"],
       input_schema=[
           P(name="payment_id", type="string", required=True),
           P(name="reason", type="string", required=False),
       ],
       output_schema={"dispute_id": "string"}),

    _t(tool_id="paypal.dispute.get", tool_name="get_dispute", service="paypal",
       domain="disputes", operation="get",
       description="Retrieves the status/details of a specific dispute.",
       method="GET", endpoint="/paypal/disputes/{dispute_id}", risk_level=RiskLevel.low,
       tags=["dispute", "read"],
       input_schema=[P(name="dispute_id", type="string", required=True)],
       output_schema={"dispute": "object"}),

    _t(tool_id="paypal.dispute.list", tool_name="get_disputes", service="paypal",
       domain="disputes", operation="list",
       description="Lists disputes, optionally filtered by customer or status. Use this to check whether a dispute is open for a given customer.",
       method="GET", endpoint="/paypal/disputes", risk_level=RiskLevel.low,
       tags=["dispute", "list", "chargeback", "open"],
       input_schema=[
           P(name="customer_name", type="string", required=False),
           P(name="status", type="string", required=False, enum=["OPEN", "RESOLVED"]),
       ],
       output_schema={"disputes": "array"}),

    _t(tool_id="paypal.dispute.resolve", tool_name="resolve_dispute", service="paypal",
       domain="disputes", operation="update",
       description="Marks a dispute as resolved.",
       method="POST", endpoint="/paypal/disputes/{dispute_id}/resolve", risk_level=RiskLevel.medium,
       tags=["dispute", "resolve"],
       input_schema=[P(name="dispute_id", type="string", required=True)],
       output_schema={"status": "string"}),

    # ---------------- REPORTS ----------------
    _t(tool_id="paypal.report.sales", tool_name="get_sales_report", service="paypal",
       domain="reports", operation="get",
       description="Returns total sales volume and transaction count for a given period (e.g. last month).",
       method="GET", endpoint="/paypal/reports/sales", risk_level=RiskLevel.low,
       tags=["report", "sales", "volume", "revenue", "analytics"],
       input_schema=[P(name="period", type="string", required=False, enum=["last_month", "last_week", "last_year", "all_time"])],
       output_schema={"total_sales": "number", "transaction_count": "integer"}),

    _t(tool_id="paypal.report.transactions", tool_name="get_transaction_history", service="paypal",
       domain="reports", operation="list",
       description="Returns a list of individual transactions for a period.",
       method="GET", endpoint="/paypal/transactions", risk_level=RiskLevel.low,
       tags=["report", "transactions", "history"],
       input_schema=[P(name="period", type="string", required=False, enum=["last_month", "last_week", "last_year", "all_time"])],
       output_schema={"transactions": "array"}),

    _t(tool_id="paypal.report.payouts", tool_name="get_payout_report", service="paypal",
       domain="reports", operation="get",
       description="Returns a summary of payouts made to the merchant over a period.",
       method="GET", endpoint="/paypal/reports/payouts", risk_level=RiskLevel.low,
       tags=["report", "payouts", "summary"],
       input_schema=[P(name="period", type="string", required=False, enum=["last_month", "last_week", "last_year"])],
       output_schema={"total_payouts": "number"}),

    # ---------------- PAYOUTS ----------------
    _t(tool_id="paypal.payout.create", tool_name="create_payout", service="paypal",
       domain="payouts", operation="create",
       description="Sends a payout to a recipient's account.",
       method="POST", endpoint="/paypal/payouts", risk_level=RiskLevel.high,
       tags=["payout", "send", "create"],
       input_schema=[
           P(name="recipient", type="string", required=True),
           P(name="amount", type="number", required=True, minimum=0.01),
       ],
       output_schema={"payout_id": "string"}),

    _t(tool_id="paypal.payout.get", tool_name="get_payout", service="paypal",
       domain="payouts", operation="get",
       description="Retrieves the status of a specific payout.",
       method="GET", endpoint="/paypal/payouts/{payout_id}", risk_level=RiskLevel.low,
       tags=["payout", "read"],
       input_schema=[P(name="payout_id", type="string", required=True)],
       output_schema={"payout": "object"}),

    _t(tool_id="paypal.payout.list", tool_name="get_payouts", service="paypal",
       domain="payouts", operation="list",
       description="Lists payouts made to recipients.",
       method="GET", endpoint="/paypal/payouts", risk_level=RiskLevel.low,
       tags=["payout", "list"],
       input_schema=[],
       output_schema={"payouts": "array"}),

    # ---------------- BALANCE / MERCHANT ----------------
    _t(tool_id="paypal.balance.get", tool_name="get_balance", service="paypal",
       domain="account", operation="get",
       description="Returns the current account balance available to the merchant.",
       method="GET", endpoint="/paypal/balance", risk_level=RiskLevel.low,
       tags=["balance", "account", "funds"],
       input_schema=[],
       output_schema={"balance": "number", "currency": "string"}),

    _t(tool_id="paypal.merchant.get", tool_name="get_merchant_information", service="paypal",
       domain="account", operation="get",
       description="Returns merchant profile information (business name, ID, country).",
       method="GET", endpoint="/paypal/merchant", risk_level=RiskLevel.low,
       tags=["merchant", "account", "profile"],
       input_schema=[],
       output_schema={"merchant": "object"}),

    # ---------------- AUTH / SYSTEM (non-executable via mock, but present in registry) ----------------
    _t(tool_id="paypal.auth.token", tool_name="get_access_token", service="paypal",
       domain="authentication", operation="create",
       description="Obtains an OAuth2 access token for authenticating subsequent API calls.",
       method="POST", endpoint="/paypal/oauth2/token", risk_level=RiskLevel.medium,
       tags=["auth", "oauth", "token"], required_auth=False,
       input_schema=[],
       output_schema={"access_token": "string"}),

    # ---------------- KNOWLEDGE / SYSTEM (special tools, not part of the mock PayPal API) ----------------
    _t(tool_id="system.rag.search", tool_name="rag_search", service="internal",
       domain="knowledge", operation="search",
       description="Searches the local knowledge base (product docs, guides, FAQs) to answer conceptual questions, e.g. 'how do disputes work'.",
       method="POST", endpoint="/internal/rag/search", risk_level=RiskLevel.low, required_auth=False,
       tags=["knowledge", "docs", "rag", "explain", "how"],
       input_schema=[P(name="query", type="string", required=True)],
       output_schema={"passages": "array"}),

    _t(tool_id="system.search", tool_name="system_search", service="internal",
       domain="system", operation="search",
       description="Searches the agent's own system: registered tools, execution history, and logs. Use for questions like 'what tools manage invoices' or 'status of my last request'.",
       method="POST", endpoint="/internal/system/search", risk_level=RiskLevel.low, required_auth=False,
       tags=["system", "meta", "registry", "logs", "status"],
       input_schema=[P(name="query", type="string", required=True)],
       output_schema={"results": "array"}),
]


def build_core_tools() -> list[Tool]:
    return [Tool(**t) for t in CORE_TOOLS]
