"""
The Tool Registry: a centralized, dynamically searchable store of tools.

Deliberately does NOT contain any "if user says X use tool Y" logic. It only
offers metadata-based lookups (by domain, by service, by tag, by id) that
the retrieval/ranking layers build on top of.
"""
import json
import threading
from pathlib import Path
from typing import Dict, List, Optional

from app.config import TOOLS_FILE
from app.registry.core_tools import build_core_tools
from app.registry.schema import Tool


class ToolRegistry:
    def __init__(self):
        self._lock = threading.RLock()
        self._tools: Dict[str, Tool] = {}
        self.load()

    def load(self, path: Optional[Path] = None) -> None:
        path = path or TOOLS_FILE
        with self._lock:
            self._tools.clear()
            if path.exists():
                with open(path) as f:
                    raw = json.load(f)
                for item in raw:
                    try:
                        tool = Tool(**item)
                        self._tools[tool.tool_id] = tool
                    except Exception:
                        # Skip malformed synthetic entries rather than crash the registry
                        continue
            else:
                # Fall back to the core tool set only
                for tool in build_core_tools():
                    self._tools[tool.tool_id] = tool

    def reload(self) -> None:
        self.load()

    def all(self) -> List[Tool]:
        with self._lock:
            return list(self._tools.values())

    def get(self, tool_id: str) -> Optional[Tool]:
        return self._tools.get(tool_id)

    def get_by_name(self, tool_name: str) -> Optional[Tool]:
        for t in self._tools.values():
            if t.tool_name == tool_name:
                return t
        return None

    def count(self) -> int:
        return len(self._tools)

    def domains(self) -> List[str]:
        return sorted({t.domain for t in self._tools.values()})

    def services(self) -> List[str]:
        return sorted({t.service for t in self._tools.values()})

    def by_domain(self, domain: str) -> List[Tool]:
        return [t for t in self._tools.values() if t.domain == domain]

    def by_tag(self, tag: str) -> List[Tool]:
        return [t for t in self._tools.values() if tag in t.tags]

    def search_by_name_substring(self, query: str) -> List[Tool]:
        q = query.lower()
        return [t for t in self._tools.values() if q in t.tool_name.lower() or q in t.description.lower()]


# Module-level singleton so all requests within the process share one registry
registry = ToolRegistry()
