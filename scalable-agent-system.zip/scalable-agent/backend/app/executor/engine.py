"""
Execution Engine.

Runs an ExecutionPlan's steps against the mock PayPal API (in-process ASGI,
see app/mock_paypal.py) or against the internal RAG / system-search tools.

Features implemented per assignment section 10:
- sequential execution (default; steps can depend on prior outputs)
- retries with exponential backoff (max_retries configurable)
- timeout per call
- error handling that stops the plan on unrecoverable failure but preserves
  partial results
- output-passing: a later step's parameters may reference
  "$previous_result.<field>" or "$step_<n>.<field>" to consume an earlier
  step's result
- full execution trace + per-step timing, persisted via StateStore
"""
from __future__ import annotations
import asyncio
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import httpx

from app.config import MAX_RETRIES, RETRY_BASE_DELAY_SECONDS, EXECUTION_TIMEOUT_SECONDS
from app.mock_paypal import mock_paypal_app
from app.rag.rag_engine import rag_engine
from app.system_search.search import system_search
from app.registry.schema import Tool, ExecutionPlan
from app.registry.store import ToolRegistry
from app.validation.validator import validate_parameters
from app.memory.state import StateStore

REF_PATTERN = re.compile(r"^\$(previous_result|step_\d+)\.(.+)$")


@dataclass
class StepOutcome:
    tool_id: str
    tool_name: str
    parameters: Dict[str, Any]
    success: bool
    result: Optional[Any] = None
    error: Optional[str] = None
    retries: int = 0
    latency_ms: float = 0.0


@dataclass
class ExecutionTrace:
    execution_id: str
    domain: str
    tools_retrieved: int
    total_tools_available: int
    steps: List[StepOutcome] = field(default_factory=list)
    status: str = "running"
    final_message: str = ""
    total_latency_ms: float = 0.0


def _resolve_references(parameters: Dict[str, Any], step_results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Replaces $previous_result.<field> / $step_N.<field> with real values."""
    resolved = {}
    for key, value in parameters.items():
        if isinstance(value, str):
            m = REF_PATTERN.match(value)
            if m:
                ref, field_name = m.groups()
                if ref == "previous_result" and step_results:
                    source = step_results[-1]
                else:
                    idx = int(ref.split("_")[1])
                    source = step_results[idx] if idx < len(step_results) else {}
                resolved[key] = source.get(field_name, value)
                continue
        resolved[key] = value
    return resolved


class ExecutionEngine:
    def __init__(self, registry: ToolRegistry, state: StateStore):
        self.registry = registry
        self.state = state

    async def _call_mock_api(self, tool: Tool, parameters: Dict[str, Any]) -> Any:
        """Executes a single tool call against the mock PayPal ASGI app."""
        path_params = re.findall(r"\{(\w+)\}", tool.endpoint)
        endpoint = tool.endpoint
        body_params = dict(parameters)
        query_params = {}

        for pp in path_params:
            if pp not in body_params:
                raise ValueError(f"Missing path parameter '{pp}' for {tool.tool_id}")
            endpoint = endpoint.replace("{" + pp + "}", str(body_params.pop(pp)))

        transport = httpx.ASGITransport(app=mock_paypal_app)
        async with httpx.AsyncClient(transport=transport, base_url="http://mock-paypal", timeout=EXECUTION_TIMEOUT_SECONDS) as client:
            if tool.method == "GET":
                resp = await client.get(endpoint, params=body_params)
            elif tool.method == "DELETE":
                resp = await client.delete(endpoint)
            elif tool.method == "PATCH":
                resp = await client.patch(endpoint, json=body_params)
            else:  # POST
                resp = await client.post(endpoint, json=body_params if body_params else {})

            if resp.status_code >= 400:
                raise RuntimeError(f"Mock API returned {resp.status_code}: {resp.text}")
            return resp.json()

    async def _call_internal_tool(self, tool: Tool, parameters: Dict[str, Any]) -> Any:
        if tool.tool_id == "system.rag.search":
            return rag_engine.search(parameters.get("query", ""))
        if tool.tool_id == "system.search":
            return system_search(parameters.get("query", ""), self.registry, self.state)
        raise ValueError(f"No internal handler for {tool.tool_id}")

    async def _execute_single_step(self, tool: Tool, parameters: Dict[str, Any]) -> StepOutcome:
        attempt = 0
        last_error = None
        start = time.perf_counter()

        while attempt <= MAX_RETRIES:
            try:
                if tool.service == "internal":
                    result = await self._call_internal_tool(tool, parameters)
                else:
                    result = await self._call_mock_api(tool, parameters)
                latency_ms = (time.perf_counter() - start) * 1000
                return StepOutcome(
                    tool_id=tool.tool_id, tool_name=tool.tool_name, parameters=parameters,
                    success=True, result=result, retries=attempt, latency_ms=latency_ms,
                )
            except Exception as e:
                last_error = str(e)
                attempt += 1
                if attempt <= MAX_RETRIES:
                    await asyncio.sleep(RETRY_BASE_DELAY_SECONDS * (2 ** (attempt - 1)))

        latency_ms = (time.perf_counter() - start) * 1000
        return StepOutcome(
            tool_id=tool.tool_id, tool_name=tool.tool_name, parameters=parameters,
            success=False, error=last_error, retries=attempt - 1, latency_ms=latency_ms,
        )

    async def execute_plan(self, plan: ExecutionPlan, execution_id: str, domain: str,
                            tools_retrieved: int, total_tools_available: int) -> ExecutionTrace:
        trace = ExecutionTrace(
            execution_id=execution_id, domain=domain,
            tools_retrieved=tools_retrieved, total_tools_available=total_tools_available,
        )
        overall_start = time.perf_counter()
        step_results: List[Dict[str, Any]] = []

        for step in plan.steps:
            tool = self.registry.get_by_name(step.tool)
            if tool is None:
                outcome = StepOutcome(
                    tool_id=step.tool, tool_name=step.tool, parameters=step.parameters,
                    success=False, error=f"Tool '{step.tool}' was not in the retrieved/allowed set - refusing to invent it.",
                )
                trace.steps.append(outcome)
                trace.status = "failed"
                break

            resolved_params = _resolve_references(step.parameters, step_results)

            validation = validate_parameters(tool, resolved_params)
            if not validation.valid:
                outcome = StepOutcome(
                    tool_id=tool.tool_id, tool_name=tool.tool_name, parameters=resolved_params,
                    success=False, error=validation.clarification_message(),
                )
                trace.steps.append(outcome)
                trace.status = "needs_clarification"
                self.state.record_step_result(execution_id, tool.tool_id, resolved_params, None,
                                               False, outcome.error, 0, 0.0)
                break

            outcome = await self._execute_single_step(tool, resolved_params)
            trace.steps.append(outcome)
            self.state.record_step_result(
                execution_id, tool.tool_id, resolved_params, outcome.result,
                outcome.success, outcome.error, outcome.retries, outcome.latency_ms,
            )

            if not outcome.success:
                trace.status = "failed"
                break

            step_results.append(outcome.result if isinstance(outcome.result, dict) else {})

        else:
            trace.status = "success"

        trace.total_latency_ms = (time.perf_counter() - overall_start) * 1000
        return trace
