"""
Tool Ranker.

Takes the semantically-retrieved candidates and re-scores them using a
weighted blend of signals, exactly as specified in the assignment:

final_score =
    0.45 * semantic_similarity +
    0.20 * domain_match +
    0.15 * parameter_match +
    0.10 * historical_success +
    0.10 * reliability

Weights are configurable via app.config.RANK_WEIGHTS / env vars.
"""
from __future__ import annotations
import re
from dataclasses import dataclass
from typing import List, Optional, Tuple

from app.config import RANK_WEIGHTS
from app.registry.schema import Tool
from app.memory.state import StateStore


@dataclass
class RankedTool:
    tool: Tool
    semantic_similarity: float
    domain_match: float
    parameter_match: float
    historical_success: float
    reliability: float
    final_score: float


ID_TOKEN_RE = re.compile(r"\b[A-Za-z]{2,6}-[A-Za-z0-9]+\b")


def _parameter_match_score(tool: Tool, query: str) -> float:
    """
    Rough heuristic: how many of the tool's parameter names (or close
    synonyms) appear to be satisfiable from the query text. This is not a
    full extraction - real value extraction happens later in the planner -
    it's a cheap prior signal for ranking.
    """
    if not tool.input_schema:
        return 0.5  # no params required, so nothing to mismatch
    q = query.lower()
    has_id_token = bool(ID_TOKEN_RE.search(query))
    hints = {
        "amount": ["$", "dollar", "amount", "usd", "eur", "gbp"],
        "customer_name": ["for ", "customer", "client", "user", "name"],
        "period": ["last month", "last week", "last year", "this month"],
    }
    matches = 0
    total = len(tool.input_schema)
    for p in tool.input_schema:
        # Any "<noun>_id" parameter is satisfied either by its noun appearing
        # in the query ("customer information for...") or by an ID-shaped
        # token being present anywhere in the query ("CUST-1", "PAY-123") -
        # generalizes across every entity type without hardcoding each one.
        if p.name.endswith("_id"):
            noun = p.name[:-3].replace("_", " ")
            if noun in q or has_id_token:
                matches += 1
            continue
        keys = hints.get(p.name, [p.name.replace("_", " ")])
        if any(k in q for k in keys):
            matches += 1
    return matches / total if total else 0.5


def rank_tools(
    query: str,
    retrieved: List[Tuple[Tool, float]],
    domain_scores: List[Tuple[str, float]],
    state: StateStore,
    weights: dict | None = None,
) -> List[RankedTool]:
    """
    `domain_scores` is the DomainRouter's ranked (domain, score) list for
    this query (not just the single winning domain) - the domain_match
    signal is each tool's domain score normalized against the winning
    domain's score, rather than a flat "1.0 if top domain else 0.3". This
    matters for genuinely cross-domain queries (e.g. "how do disputes
    work?" scores close on both "disputes" and "knowledge") where a flat
    binary would let the router's top pick permanently starve out a very
    close runner-up domain's tools during ranking.
    """
    weights = weights or RANK_WEIGHTS
    ranked: List[RankedTool] = []

    scores_by_domain = dict(domain_scores)
    max_domain_score = max(scores_by_domain.values(), default=0.0)

    for tool, sim in retrieved:
        if tool.domain in scores_by_domain and max_domain_score > 0:
            domain_match = scores_by_domain[tool.domain] / max_domain_score
        elif tool.domain in scores_by_domain:
            domain_match = 1.0
        else:
            domain_match = 0.1  # tool's domain wasn't part of routing at all
        param_match = _parameter_match_score(tool, query)
        historical = state.get_tool_success_rate(tool.tool_id)
        reliability = state.get_tool_reliability(tool.tool_id)

        final = (
            weights["semantic_similarity"] * sim
            + weights["domain_match"] * domain_match
            + weights["parameter_match"] * param_match
            + weights["historical_success"] * historical
            + weights["reliability"] * reliability
        )

        ranked.append(RankedTool(
            tool=tool,
            semantic_similarity=sim,
            domain_match=domain_match,
            parameter_match=param_match,
            historical_success=historical,
            reliability=reliability,
            final_score=final,
        ))

    ranked.sort(key=lambda r: r.final_score, reverse=True)
    return ranked
