"""
Observability.

Structured logging (JSON lines to stdout, easy to pipe into any log
aggregator) plus a lightweight in-memory trace builder that the API layer
turns into the "execution trace" the UI displays:

Request -> Domain Router -> Retriever -> Ranker -> Planner -> Validator ->
Tool 1 -> Tool 2 -> Final Response
"""
from __future__ import annotations
import json
import logging
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Dict, List

logger = logging.getLogger("agentic_system")
logging.basicConfig(level=logging.INFO, format="%(message)s")


def log_event(event: str, **fields: Any) -> None:
    record = {"event": event, "ts": time.time(), **fields}
    logger.info(json.dumps(record, default=str))


@dataclass
class TraceStage:
    name: str
    started_at: float
    ended_at: float | None = None
    detail: Dict[str, Any] = field(default_factory=dict)

    @property
    def latency_ms(self) -> float:
        if self.ended_at is None:
            return 0.0
        return (self.ended_at - self.started_at) * 1000


class RequestTracer:
    """One instance per incoming /api/chat request. Captures per-stage
    latency and metadata for display in the UI's execution trace panel."""

    def __init__(self, request_id: str):
        self.request_id = request_id
        self.stages: List[TraceStage] = []
        self._start = time.perf_counter()

    @contextmanager
    def stage(self, name: str, **detail: Any):
        stage = TraceStage(name=name, started_at=time.perf_counter(), detail=dict(detail))
        try:
            yield stage
        finally:
            stage.ended_at = time.perf_counter()
            self.stages.append(stage)
            log_event("stage_complete", request_id=self.request_id, stage=name,
                      latency_ms=stage.latency_ms, **stage.detail)

    @property
    def total_latency_ms(self) -> float:
        return (time.perf_counter() - self._start) * 1000

    def as_list(self) -> List[Dict[str, Any]]:
        return [
            {"stage": s.name, "latency_ms": round(s.latency_ms, 2), "detail": s.detail}
            for s in self.stages
        ]
