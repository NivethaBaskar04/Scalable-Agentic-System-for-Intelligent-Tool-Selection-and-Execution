"""
Agent Orchestrator.

Implements the exact pipeline from the assignment:

USER
 -> Intent / Task Analyzer   (folded into the domain router's classification)
 -> Tool Domain Router
 -> Semantic Tool Retriever
 -> Tool Ranker
 -> Relevant Tool Subset
 -> LLM Planner
 -> Parameter Validator
 -> Execution Engine
 -> Result Validator
 -> Final Response

Nothing here special-cases individual tool names - the routing/ranking
modules are metadata + similarity driven, so this file is the only "glue"
and stays generic even as the registry grows from 10 to 1000+ tools.
"""
from __future__ import annotations
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from app.config import TOP_K_TOOLS, TOP_K_DOMAIN_CANDIDATES, RETRIEVAL_CANDIDATE_K, RISK_LEVELS_REQUIRING_CONFIRMATION
from app.domain_router import DomainRouter
from app.retrieval.tfidf_retriever import TfidfRetriever
from app.ranking.ranker import rank_tools, RankedTool
from app.planner.planner import generate_plan
from app.planner.llm_provider import get_provider
from app.executor.engine import ExecutionEngine
from app.memory.state import StateStore
from app.observability.tracer import RequestTracer, log_event
from app.registry.store import ToolRegistry
from app.registry.schema import ExecutionPlan


@dataclass
class ChatResult:
    request_id: str
    execution_id: Optional[str]
    domain: str
    total_tools_available: int
    tools_retrieved: List[Dict[str, Any]]
    plan: Dict[str, Any]
    trace: List[Dict[str, Any]]
    status: str
    message: str
    requires_confirmation: bool = False
    confirmation_prompt: Optional[str] = None
    steps: List[Dict[str, Any]] = field(default_factory=list)
    total_latency_ms: float = 0.0
    llm_provider: str = "mock"


class AgentOrchestrator:
    def __init__(self, registry: ToolRegistry, state: StateStore):
        self.registry = registry
        self.state = state
        self.domain_router = DomainRouter(registry)
        self.retriever = TfidfRetriever(registry)
        self.executor = ExecutionEngine(registry, state)

    def rebuild_indexes(self) -> None:
        """Call after the registry changes size (e.g. generate_tools.py ran)."""
        self.domain_router.rebuild()
        self.retriever.rebuild()

    async def handle_query(self, query: str, conversation_id: Optional[str] = None,
                            confirm: bool = False) -> ChatResult:
        request_id = str(uuid.uuid4())
        conversation_id = conversation_id or str(uuid.uuid4())
        self.state.ensure_conversation(conversation_id)
        tracer = RequestTracer(request_id)
        provider = get_provider()

        log_event("request_received", request_id=request_id, query=query)

        # ---- 1 & 2: Intent analysis + Domain routing ----
        with tracer.stage("domain_router") as stage:
            domain_scores = self.domain_router.route(query, top_k=TOP_K_DOMAIN_CANDIDATES)
            top_domain = domain_scores[0][0] if domain_scores else None
            stage.detail = {"domain_scores": domain_scores, "chosen_domain": top_domain}

        # ---- 3: Semantic retrieval (scoped to the routed domain(s) when possible) ----
        with tracer.stage("retriever") as stage:
            candidate_pool = None
            if domain_scores:
                candidate_pool = []
                for domain, _ in domain_scores:
                    candidate_pool.extend(self.registry.by_domain(domain))
                # rag_search / system_search always compete for a slot,
                # regardless of which domain(s) won routing - a dispute-heavy
                # domain match should not silently starve out a genuinely
                # conceptual "how does X work" or meta "what tools exist"
                # question before the ranker even sees it.
                pool_ids = {t.tool_id for t in candidate_pool}
                for fallback_domain in ("knowledge", "system"):
                    for t in self.registry.by_domain(fallback_domain):
                        if t.tool_id not in pool_ids:
                            candidate_pool.append(t)
                            pool_ids.add(t.tool_id)

            # Retrieve a wider candidate pool than what will ultimately be
            # shown to the planner - the ranker below re-scores using
            # domain/parameter/history signals in addition to raw text
            # similarity, so it needs real alternatives to choose between.
            retrieved = self.retriever.retrieve(query, top_k=RETRIEVAL_CANDIDATE_K, candidate_pool=candidate_pool)
            stage.detail = {
                "candidate_k": RETRIEVAL_CANDIDATE_K,
                "retrieved_tool_ids": [t.tool_id for t, _ in retrieved],
                "candidate_pool_size": len(candidate_pool) if candidate_pool is not None else self.registry.count(),
            }

        # ---- 4: Ranking, then truncate to the final subset the planner/LLM sees ----
        with tracer.stage("ranker") as stage:
            all_ranked: List[RankedTool] = rank_tools(query, retrieved, domain_scores, self.state)
            ranked = all_ranked[:TOP_K_TOOLS]
            stage.detail = {
                "top_k_shown_to_planner": TOP_K_TOOLS,
                "ranked": [
                    {"tool_name": r.tool.tool_name, "final_score": round(r.final_score, 4)}
                    for r in ranked
                ]
            }

        total_tools_available = self.registry.count()

        if not ranked:
            return ChatResult(
                request_id=request_id, execution_id=None, domain=top_domain or "unknown",
                total_tools_available=total_tools_available, tools_retrieved=[],
                plan={"goal": query, "steps": []}, trace=tracer.as_list(), status="no_tools_found",
                message="I couldn't find any tool relevant to that request. Try rephrasing, "
                        "or ask a knowledge question (I can search documentation too).",
                total_latency_ms=tracer.total_latency_ms, llm_provider=provider.name,
            )

        # ---- 5: LLM Planner (sees ONLY the ranked/retrieved subset) ----
        with tracer.stage("planner") as stage:
            plan: ExecutionPlan = generate_plan(query, ranked)
            stage.detail = {"plan": plan.model_dump()}

        if not plan.steps:
            execution_id = self.state.start_execution(conversation_id, query, top_domain or "unknown",
                                                        len(ranked), total_tools_available)
            self.state.complete_execution(execution_id, plan.model_dump(), "no_plan", None, tracer.total_latency_ms)
            return ChatResult(
                request_id=request_id, execution_id=execution_id, domain=top_domain or "unknown",
                total_tools_available=total_tools_available,
                tools_retrieved=self._retrieved_summary(ranked),
                plan=plan.model_dump(), trace=tracer.as_list(), status="no_plan",
                message="I wasn't able to work out a concrete action for that request. "
                        "Could you rephrase it as a specific task?",
                total_latency_ms=tracer.total_latency_ms, llm_provider=provider.name,
            )

        # ---- Risk / confirmation check (section 22) ----
        risky_steps = [
            s for s in plan.steps
            if (t := self.registry.get_by_name(s.tool)) and t.risk_level.value in RISK_LEVELS_REQUIRING_CONFIRMATION
        ]
        if risky_steps and not confirm:
            description = "; ".join(f"{s.tool}({s.parameters})" for s in risky_steps)
            return ChatResult(
                request_id=request_id, execution_id=None, domain=top_domain or "unknown",
                total_tools_available=total_tools_available,
                tools_retrieved=self._retrieved_summary(ranked),
                plan=plan.model_dump(), trace=tracer.as_list(), status="needs_confirmation",
                message=f"This involves a high-risk operation: {description}. Please confirm to proceed.",
                requires_confirmation=True,
                confirmation_prompt=f"Proceed with: {description}?",
                total_latency_ms=tracer.total_latency_ms, llm_provider=provider.name,
            )

        # ---- 6 & 7: Validation happens inside the executor per-step, so a
        # partially-valid multi-step plan still runs its valid prefix ----
        execution_id = self.state.start_execution(conversation_id, query, top_domain or "unknown",
                                                    len(ranked), total_tools_available)

        with tracer.stage("executor") as stage:
            trace = await self.executor.execute_plan(plan, execution_id, top_domain or "unknown",
                                                       len(ranked), total_tools_available)
            stage.detail = {"status": trace.status, "step_count": len(trace.steps)}

        self.state.complete_execution(execution_id, plan.model_dump(), trace.status, None, tracer.total_latency_ms)

        # ---- 8: Result validation + natural language response ----
        message, status = self._compose_response(query, plan, trace)

        return ChatResult(
            request_id=request_id, execution_id=execution_id, domain=top_domain or "unknown",
            total_tools_available=total_tools_available,
            tools_retrieved=self._retrieved_summary(ranked),
            plan=plan.model_dump(), trace=tracer.as_list(), status=status, message=message,
            steps=[
                {
                    "tool_id": s.tool_id, "tool_name": s.tool_name, "parameters": s.parameters,
                    "success": s.success, "result": s.result, "error": s.error,
                    "retries": s.retries, "latency_ms": round(s.latency_ms, 2),
                }
                for s in trace.steps
            ],
            total_latency_ms=tracer.total_latency_ms, llm_provider=provider.name,
        )

    def _retrieved_summary(self, ranked: List[RankedTool]) -> List[Dict[str, Any]]:
        return [
            {
                "tool_id": r.tool.tool_id, "tool_name": r.tool.tool_name,
                "domain": r.tool.domain, "description": r.tool.description,
                "final_score": round(r.final_score, 4), "risk_level": r.tool.risk_level.value,
            }
            for r in ranked
        ]

    def _compose_response(self, query: str, plan: ExecutionPlan, trace) -> tuple[str, str]:
        """Result Validator + Final Response composer. Turns raw tool
        results into a natural-language sentence, without an LLM call
        (keeps the demo deterministic and free to run), but the shape is
        provider-agnostic - a real LLM could summarize `trace.steps`
        instead if desired."""
        if trace.status == "needs_clarification":
            last_error = trace.steps[-1].error if trace.steps else "Missing information."
            return last_error, "needs_clarification"

        if trace.status == "failed":
            last = trace.steps[-1] if trace.steps else None
            err = last.error if last else "Unknown error."
            return f"Sorry, that didn't complete successfully: {err}", "failed"

        if not trace.steps:
            return "I didn't find an action to take for that request.", "no_action"

        # Success path: summarize each step's result plainly.
        parts = []
        for s in trace.steps:
            r = s.result or {}
            if s.tool_name == "create_invoice":
                parts.append(f"Created invoice {r.get('invoice_id', '?')}")
            elif s.tool_name == "send_invoice":
                parts.append(f"sent invoice {s.parameters.get('invoice_id', '')}".strip())
            elif s.tool_name == "create_payment":
                parts.append(f"Created payment {r.get('payment_id', '?')} for ${s.parameters.get('amount', '?')}")
            elif s.tool_name == "capture_payment":
                parts.append(f"Captured payment {s.parameters.get('payment_id', '?')}")
            elif s.tool_name == "void_payment":
                parts.append(f"Voided payment {s.parameters.get('payment_id', '?')}")
            elif s.tool_name == "cancel_subscription":
                parts.append(f"Cancelled subscription {s.parameters.get('subscription_id', '?')}")
            elif s.tool_name == "create_subscription":
                parts.append(f"Created subscription {r.get('subscription_id', '?')}")
            elif s.tool_name == "find_customer":
                parts.append(f"Found customer {r.get('name', '?')} ({r.get('customer_id', '?')})")
            elif s.tool_name == "create_customer":
                parts.append(f"Created customer {r.get('customer_id', '?')}")
            elif s.tool_name == "refund_payment":
                parts.append(f"Refunded payment {s.parameters.get('payment_id', '?')} "
                              f"(refund {r.get('refund_id', '?')})")
            elif s.tool_name == "get_sales_report":
                parts.append(f"Total sales: ${r.get('total_sales', 0):,.2f} "
                              f"across {r.get('transaction_count', 0)} transactions")
            elif s.tool_name == "get_disputes":
                disputes = r.get("disputes", [])
                if disputes:
                    statuses = ", ".join(f"{d['id']} ({d['status']})" for d in disputes)
                    parts.append(f"Found {len(disputes)} dispute(s): {statuses}")
                else:
                    parts.append("No disputes found")
            elif s.tool_name == "rag_search":
                passages = r if isinstance(r, list) else []
                if passages:
                    top = passages[0]
                    parts.append(f"{top['text']} (source: {top['source']})")
                else:
                    parts.append("I couldn't find anything about that in the knowledge base.")
            elif s.tool_name == "system_search":
                parts.append(self._describe_system_search_result(r))
            elif s.tool_name == "get_balance":
                parts.append(f"Current balance: ${r.get('balance', 0):,.2f} {r.get('currency', 'USD')}")
            elif s.tool_name == "get_transaction_history":
                txns = r.get("transactions", [])
                parts.append(f"Found {len(txns)} transactions")
            else:
                parts.append(f"{s.tool_name} completed successfully")

        message = ". ".join(p for p in parts if p) + "."
        return message, "success"

    def _describe_system_search_result(self, r: Dict[str, Any]) -> str:
        answer_type = r.get("answer_type")
        if answer_type == "tool_count":
            return f"There are {r.get('total_tools')} tools registered across {len(r.get('domains', []))} domains"
        if answer_type == "tools_for_topic":
            names = ", ".join(m["tool_name"] for m in r.get("matches", [])[:5])
            return f"Found {r.get('count')} matching tool(s): {names}" if names else "No matching tools found"
        if answer_type == "recent_failures":
            return f"{r.get('count')} recent failure(s) found" if r.get("count") else "No recent failures"
        if answer_type == "last_execution":
            ex = r.get("execution")
            return f"Last request: '{ex['user_query']}' -> {ex['status']}" if ex else "No previous requests found"
        return "System search completed"
