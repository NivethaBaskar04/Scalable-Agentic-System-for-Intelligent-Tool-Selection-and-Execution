"""
Public API surface, per assignment section 19.
"""
from __future__ import annotations
from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.registry.store import registry
from app.memory.state import state_store
from app.agents.orchestrator import AgentOrchestrator
from app.rag.rag_engine import rag_engine
from app.system_search.search import system_search
from app.planner.llm_provider import get_provider

router = APIRouter(prefix="/api")

orchestrator = AgentOrchestrator(registry, state_store)


class ChatRequest(BaseModel):
    message: str
    conversation_id: Optional[str] = None
    confirm: bool = False


class ToolSearchRequest(BaseModel):
    query: str
    top_k: int = 5


class RagSearchRequest(BaseModel):
    query: str
    top_k: Optional[int] = None


class SystemSearchRequest(BaseModel):
    query: str


@router.post("/chat")
async def chat(req: ChatRequest):
    result = await orchestrator.handle_query(req.message, req.conversation_id, req.confirm)
    return result


@router.get("/tools")
def list_tools(domain: Optional[str] = None, service: Optional[str] = None, limit: int = 100, offset: int = 0):
    tools = registry.all()
    if domain:
        tools = [t for t in tools if t.domain == domain]
    if service:
        tools = [t for t in tools if t.service == service]
    total = len(tools)
    page = tools[offset:offset + limit]
    return {
        "total_tools_in_registry": registry.count(),
        "total_matching": total,
        "tools": [t.model_dump() for t in page],
    }


@router.get("/tools/{tool_id}")
def get_tool(tool_id: str):
    tool = registry.get(tool_id)
    if not tool:
        raise HTTPException(404, f"Tool '{tool_id}' not found")
    return tool.model_dump()


@router.post("/tools/search")
def search_tools(req: ToolSearchRequest):
    results = orchestrator.retriever.retrieve(req.query, top_k=req.top_k)
    return {
        "query": req.query,
        "total_tools_available": registry.count(),
        "results": [
            {"tool_id": t.tool_id, "tool_name": t.tool_name, "description": t.description,
             "domain": t.domain, "similarity_score": round(score, 4)}
            for t, score in results
        ],
    }


@router.get("/domains")
def list_domains():
    domains = registry.domains()
    return {
        "domains": [
            {"name": d, "tool_count": len(registry.by_domain(d))}
            for d in domains
        ]
    }


@router.post("/rag/search")
def rag_search(req: RagSearchRequest):
    from app.config import RAG_TOP_K
    top_k = req.top_k or RAG_TOP_K
    results = rag_engine.search(req.query, top_k=top_k)
    return {"query": req.query, "passages": results}


@router.post("/system/search")
def system_search_endpoint(req: SystemSearchRequest):
    return system_search(req.query, registry, state_store)


@router.get("/executions")
def list_executions(limit: int = 50):
    return {"executions": state_store.list_executions(limit=limit)}


@router.get("/executions/{execution_id}")
def get_execution(execution_id: str):
    execution = state_store.get_execution(execution_id)
    if not execution:
        raise HTTPException(404, f"Execution '{execution_id}' not found")
    return execution


@router.get("/metrics")
def get_metrics():
    summary = state_store.metrics_summary()
    provider = get_provider()
    return {
        **summary,
        "total_tools_registered": registry.count(),
        "total_domains": len(registry.domains()),
        "total_services": len(registry.services()),
        "top_k_tools_per_request": __import__("app.config", fromlist=["TOP_K_TOOLS"]).TOP_K_TOOLS,
        "llm_provider": provider.name,
        "rag_documents_indexed": rag_engine.document_count(),
        "rag_chunks_indexed": rag_engine.chunk_count(),
    }


@router.get("/health")
def health():
    return {"status": "ok", "tools_registered": registry.count()}


@router.post("/admin/reload-registry")
def reload_registry():
    """Reloads data/tools.json from disk and rebuilds all indexes - used
    after scripts/generate_tools.py changes the registry size, so the
    scalability demo can be driven live without restarting the server."""
    registry.reload()
    orchestrator.rebuild_indexes()
    return {"status": "reloaded", "total_tools": registry.count()}
