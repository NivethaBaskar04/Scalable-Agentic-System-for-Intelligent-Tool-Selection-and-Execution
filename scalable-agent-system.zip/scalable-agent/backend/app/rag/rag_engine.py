"""
RAG Pipeline Tool (rag_search).

Searches a local knowledge base of Markdown documents and returns the most
relevant passages with their source document and similarity score, per
assignment section 13. Uses TF-IDF + cosine similarity for the same reason
the tool retriever does (no external model downloads required to run);
the interface is intentionally identical in shape to what a
sentence-transformers + FAISS/Chroma implementation would expose.
"""
from __future__ import annotations
import re
from dataclasses import dataclass
from pathlib import Path
from typing import List

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from app.config import KNOWLEDGE_DIR, RAG_TOP_K


@dataclass
class Passage:
    source: str
    heading: str
    text: str
    score: float


def _chunk_markdown(path: Path) -> List[dict]:
    """Splits a markdown file into paragraph-level chunks, tracking the
    nearest preceding heading for citation purposes."""
    text = path.read_text()
    chunks = []
    current_heading = path.stem.replace("_", " ").title()
    for block in re.split(r"\n\s*\n", text):
        block = block.strip()
        if not block:
            continue
        heading_match = re.match(r"^#+\s*(.+)$", block)
        if heading_match:
            current_heading = heading_match.group(1).strip()
            continue
        cleaned = re.sub(r"^#+\s*", "", block)
        if len(cleaned) < 20:
            continue
        chunks.append({"source": path.name, "heading": current_heading, "text": cleaned})
    return chunks


class RagEngine:
    def __init__(self, knowledge_dir: Path = KNOWLEDGE_DIR):
        self.knowledge_dir = knowledge_dir
        self._chunks: List[dict] = []
        self._vectorizer: TfidfVectorizer | None = None
        self._matrix = None
        self.rebuild()

    def rebuild(self) -> None:
        self._chunks = []
        for path in sorted(self.knowledge_dir.glob("*.md")):
            self._chunks.extend(_chunk_markdown(path))

        if self._chunks:
            corpus = [c["text"] for c in self._chunks]
            self._vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
            self._matrix = self._vectorizer.fit_transform(corpus)
        else:
            self._vectorizer = None
            self._matrix = None

    def search(self, query: str, top_k: int = RAG_TOP_K) -> List[dict]:
        if not self._vectorizer or self._matrix is None:
            return []
        query_vec = self._vectorizer.transform([query])
        sims = cosine_similarity(query_vec, self._matrix)[0]
        ranked_idx = sims.argsort()[::-1][:top_k]

        results = []
        for i in ranked_idx:
            if sims[i] <= 0:
                continue
            c = self._chunks[i]
            results.append({
                "source": c["source"],
                "heading": c["heading"],
                "text": c["text"],
                "similarity_score": round(float(sims[i]), 4),
            })
        return results

    def document_count(self) -> int:
        return len({c["source"] for c in self._chunks})

    def chunk_count(self) -> int:
        return len(self._chunks)


rag_engine = RagEngine()
