"""
Semantic Tool Retriever.

Implements: query -> vector -> similarity search -> top-K tools.

The assignment's preferred stack is sentence-transformers + FAISS/ChromaDB.
Those require downloading pretrained embedding models from the internet at
runtime, which is not guaranteed in every environment (including this one),
so this implementation uses TF-IDF + cosine similarity as a fully local,
dependency-light "embedding" - it satisfies the exact same pipeline shape
(query -> vector -> nearest neighbours -> top-K) and every downstream
component (ranker, planner) is agnostic to which retriever produced the
candidates.

Swapping in real embeddings later means implementing the same
`BaseRetriever` interface with sentence-transformers + FAISS and pointing
`app.retrieval.get_retriever()` at it - nothing else in the pipeline changes.
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import List, Tuple

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from app.registry.schema import Tool
from app.registry.store import ToolRegistry


class BaseRetriever(ABC):
    @abstractmethod
    def rebuild(self) -> None: ...

    @abstractmethod
    def retrieve(self, query: str, top_k: int, candidate_pool: List[Tool] | None = None) -> List[Tuple[Tool, float]]: ...


class TfidfRetriever(BaseRetriever):
    """
    A fully local semantic retriever. Vectorizes every tool's
    `searchable_text()` once, then computes cosine similarity against the
    query vector at query time. If a `candidate_pool` (e.g. the tools in the
    domain(s) chosen by the DomainRouter) is supplied, similarity is computed
    only within that pool - this is the mechanism that lets the system scale:
    the vectorizer's *fit* corpus is the whole registry (for a stable
    vocabulary), but at query time we score, at most, a few hundred tools
    rather than 1000+.
    """

    def __init__(self, registry: ToolRegistry):
        self.registry = registry
        self._vectorizer: TfidfVectorizer | None = None
        self._tool_ids: List[str] = []
        self._matrix = None
        self.rebuild()

    def rebuild(self) -> None:
        tools = self.registry.all()
        self._tool_ids = [t.tool_id for t in tools]
        corpus = [t.searchable_text() for t in tools]
        if corpus:
            self._vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
            self._matrix = self._vectorizer.fit_transform(corpus)
        else:
            self._vectorizer = None
            self._matrix = None

    def retrieve(self, query: str, top_k: int = 5, candidate_pool: List[Tool] | None = None) -> List[Tuple[Tool, float]]:
        if not self._vectorizer or self._matrix is None:
            return []

        query_vec = self._vectorizer.transform([query])

        if candidate_pool is not None:
            pool_ids = {t.tool_id for t in candidate_pool}
            indices = [i for i, tid in enumerate(self._tool_ids) if tid in pool_ids]
            if not indices:
                return []
            sub_matrix = self._matrix[indices]
            sims = cosine_similarity(query_vec, sub_matrix)[0]
            scored = [(self._tool_ids[indices[i]], float(sims[i])) for i in range(len(indices))]
        else:
            sims = cosine_similarity(query_vec, self._matrix)[0]
            scored = [(self._tool_ids[i], float(sims[i])) for i in range(len(self._tool_ids))]

        scored.sort(key=lambda x: x[1], reverse=True)
        top = scored[:top_k]

        results = []
        for tool_id, score in top:
            tool = self.registry.get(tool_id)
            if tool:
                results.append((tool, score))
        return results
