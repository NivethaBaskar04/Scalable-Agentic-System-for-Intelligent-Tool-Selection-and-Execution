"""
LLM Provider Abstraction.

Per assignment section 21: the system must not hardcode a single LLM
provider, and must still run - fully - with no API key configured, using a
deterministic mock. `get_provider()` reads LLM_PROVIDER from config/env and
returns the right implementation; every provider exposes the same
`complete(system_prompt, user_prompt) -> str` interface so the planner
never needs to know which one is active.
"""
from __future__ import annotations
from abc import ABC, abstractmethod

from app.config import LLM_PROVIDER, ANTHROPIC_API_KEY, OPENAI_API_KEY, ANTHROPIC_MODEL, OPENAI_MODEL


class LLMProvider(ABC):
    name: str = "base"

    @abstractmethod
    def complete(self, system_prompt: str, user_prompt: str) -> str: ...

    @property
    def is_real_llm(self) -> bool:
        return True


class AnthropicProvider(LLMProvider):
    name = "anthropic"

    def __init__(self):
        import anthropic
        self.client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

    def complete(self, system_prompt: str, user_prompt: str) -> str:
        response = self.client.messages.create(
            model=ANTHROPIC_MODEL,
            max_tokens=1000,
            system=system_prompt,
            messages=[{"role": "user", "content": user_prompt}],
        )
        parts = [b.text for b in response.content if getattr(b, "type", None) == "text"]
        return "\n".join(parts)


class OpenAIProvider(LLMProvider):
    name = "openai"

    def __init__(self):
        import openai
        self.client = openai.OpenAI(api_key=OPENAI_API_KEY)

    def complete(self, system_prompt: str, user_prompt: str) -> str:
        response = self.client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            max_tokens=1000,
        )
        return response.choices[0].message.content or ""


class MockProvider(LLMProvider):
    """
    Deterministic, rule-based "planner brain" used when no API key is
    configured. It does not call any external model - see
    app/planner/mock_planner.py for the actual planning heuristics that use
    this. Kept here as a provider so the rest of the app can treat
    "no key configured" uniformly.
    """
    name = "mock"

    def complete(self, system_prompt: str, user_prompt: str) -> str:
        return ""

    @property
    def is_real_llm(self) -> bool:
        return False


_provider_instance: LLMProvider | None = None


def get_provider() -> LLMProvider:
    global _provider_instance
    if _provider_instance is not None:
        return _provider_instance

    provider = LLM_PROVIDER.lower()
    try:
        if provider == "anthropic" and ANTHROPIC_API_KEY:
            _provider_instance = AnthropicProvider()
        elif provider == "openai" and OPENAI_API_KEY:
            _provider_instance = OpenAIProvider()
        else:
            _provider_instance = MockProvider()
    except Exception:
        # If the SDK/key is misconfigured, fail soft into the mock planner
        # rather than crashing the whole application (section 21 requirement).
        _provider_instance = MockProvider()

    return _provider_instance


def reset_provider() -> None:
    """Used by tests / hot config reloads."""
    global _provider_instance
    _provider_instance = None
