"""
Mock (deterministic) planner.

This is what runs the whole demo when LLM_PROVIDER=mock or no API key is
configured (assignment section 21 requires the app to be fully demoable
without paid APIs). It never sees or has access to the full tool registry -
only whatever the retriever+ranker already narrowed down to - so even this
rule-based stand-in obeys the same "cannot invent tools" constraint a real
LLM planner would.

It works by:
1. Extracting entities (amounts, ids, names, periods) from the query with
   regexes.
2. Scoring each *retrieved* tool against a small keyword table for its
   operation/domain.
3. Picking the best-matching tool, and - for well-known 2-step patterns
   (create+send invoice, find+create+send) - chaining a second/third step
   if the corresponding tool is also in the retrieved set.
4. Leaving any parameter it cannot find as missing, so the validator will
   ask the user for it rather than the planner guessing.
"""
from __future__ import annotations
import re
from typing import Dict, List, Optional

from app.ranking.ranker import RankedTool
from app.registry.schema import ExecutionPlan, ExecutionStep

AMOUNT_RE = re.compile(r"\$?\s?(\d+(?:\.\d{1,2})?)")
ID_RE = re.compile(r"\b([A-Za-z]{2,6}-[A-Za-z0-9]+)\b")
NAME_RE = re.compile(r"\bfor\s+([A-Z][a-zA-Z]+(?:\s[A-Z][a-zA-Z]+)?)\b")
PERIOD_MAP = {
    "last month": "last_month", "past month": "last_month",
    "last week": "last_week", "past week": "last_week",
    "last year": "last_year", "past year": "last_year",
    "this month": "last_month", "all time": "all_time",
}


def _extract_amount(query: str) -> Optional[float]:
    m = AMOUNT_RE.search(query)
    if m and ("$" in query or "dollar" in query.lower() or re.search(r"for\s+\$?\d", query)):
        try:
            return float(m.group(1))
        except ValueError:
            return None
    return None


def _extract_id(query: str, prefix_hint: str) -> Optional[str]:
    for m in ID_RE.finditer(query):
        token = m.group(1)
        if token.upper().startswith(prefix_hint.upper()):
            return token.upper()
    return None


def _extract_name(query: str) -> Optional[str]:
    m = NAME_RE.search(query)
    if m:
        return m.group(1)
    # also catch "user_123"-style identifiers used as a customer reference
    m2 = re.search(r"\buser_[A-Za-z0-9]+\b", query)
    if m2:
        return m2.group(0)
    return None


def _extract_period(query: str) -> Optional[str]:
    q = query.lower()
    for phrase, value in PERIOD_MAP.items():
        if phrase in q:
            return value
    return None


# Keyword hints per tool_name, used to score intent match beyond what the
# semantic retriever/ranker already did - this stage picks *which specific*
# retrieved tool(s) best match the verb structure of the request.
INTENT_KEYWORDS: Dict[str, List[str]] = {
    "create_invoice": ["invoice"],
    "send_invoice": ["send invoice", "send it", "email invoice"],
    "get_invoice": ["invoice status", "check invoice", "get invoice"],
    "cancel_invoice": ["cancel invoice"],
    "list_invoices": ["list invoices", "all invoices", "invoices"],
    "send_invoice_reminder": ["remind", "reminder"],

    "create_payment": ["create payment", "charge", "new payment"],
    "capture_payment": ["capture"],
    "refund_payment": ["refund"],
    "void_payment": ["void"],
    "get_payment": ["payment status", "check payment"],
    "list_payments": ["list payments", "all payments"],

    "create_customer": ["new customer", "add customer", "create customer"],
    "find_customer": ["find customer", "look up", "lookup"],
    "get_customer": ["customer info", "customer information", "get customer"],
    "update_customer": ["update customer", "change customer"],
    "delete_customer": ["delete customer", "remove customer"],
    "list_customers": ["list customers", "all customers"],

    "create_subscription": ["create subscription", "new subscription", "sign up"],
    "cancel_subscription": ["cancel subscription", "cancel my subscription"],
    "get_subscription": ["subscription status"],
    "list_subscriptions": ["list subscriptions", "all subscriptions"],
    "update_subscription_plan": ["change plan", "upgrade", "downgrade"],

    "create_dispute": ["file a dispute", "open a dispute", "create dispute", "start a dispute"],
    "get_dispute": ["dispute status", "dispute detail"],
    "get_disputes": ["dispute", "disputes", "open dispute", "is there a dispute"],
    "resolve_dispute": ["resolve dispute", "close dispute"],

    "get_sales_report": ["sales", "sales volume", "revenue", "how much did i make"],
    "get_transaction_history": ["transaction history", "transactions", "list of transactions"],
    "get_payout_report": ["payout report", "how much was paid out"],

    "create_payout": ["send a payout", "pay out", "create payout"],
    "get_payout": ["payout status"],
    "get_payouts": ["list payouts", "all payouts", "payouts"],

    "get_balance": ["balance", "how much do i have", "available funds"],
    "get_merchant_information": ["merchant info", "business info", "account info"],
    "get_access_token": ["access token", "oauth", "authenticate"],

    "rag_search": ["how do", "how does", "explain", "why does", "work?", "how disputes", "how invoic"],
    "system_search": ["what tools", "which tools", "status of my", "last request", "how many tools",
                       "tools available", "tools manage", "system", "registered"],
}


def _score_tool(tool_name: str, query: str) -> float:
    q = query.lower()
    keywords = INTENT_KEYWORDS.get(tool_name, [])
    score = 0.0
    for kw in keywords:
        if kw in q:
            score += 1.0
    return score


def build_mock_plan(query: str, ranked_tools: List[RankedTool]) -> ExecutionPlan:
    if not ranked_tools:
        return ExecutionPlan(goal=query, steps=[], clarification_needed=
                              "I couldn't find any tools relevant to that request.")

    by_name = {rt.tool.tool_name: rt for rt in ranked_tools}

    # Combine the ranker's final_score with this stage's keyword-intent score
    # so the mock planner still benefits from semantic+domain+history ranking
    # rather than keywords alone.
    scored = []
    for rt in ranked_tools:
        intent_score = _score_tool(rt.tool.tool_name, query)
        # rag_search / system_search are penalized by domain-match (they sit
        # in their own low-priority "knowledge"/"system" domains), so their
        # keyword intent signal needs extra weight to compete fairly against
        # an in-domain action tool for genuinely conceptual/meta questions.
        if rt.tool.tool_name in ("rag_search", "system_search") and intent_score > 0:
            intent_score *= 2.5
        combined = rt.final_score + intent_score
        scored.append((combined, rt))
    scored.sort(key=lambda x: x[0], reverse=True)

    top_tool = scored[0][1].tool
    steps: List[ExecutionStep] = []

    amount = _extract_amount(query)
    period = _extract_period(query)
    name = _extract_name(query)

    # ---- Knowledge / system meta tools short-circuit everything else ----
    if top_tool.tool_name == "rag_search":
        return ExecutionPlan(goal=query, steps=[ExecutionStep(tool="rag_search", parameters={"query": query})])
    if top_tool.tool_name == "system_search":
        return ExecutionPlan(goal=query, steps=[ExecutionStep(tool="system_search", parameters={"query": query})])

    # ---- Invoice creation/send flow (only when that's genuinely the top
    # intent - other invoice operations like cancel/get/list fall through
    # to the generic single-step handling below, using whatever tool the
    # ranker actually picked). ----
    if top_tool.tool_name in ("create_invoice", "send_invoice"):
        wants_send = any(w in query.lower() for w in ["send", "and send", "then send"])
        wants_create = "create_invoice" in by_name and (
            top_tool.tool_name == "create_invoice" or "create" in query.lower() or amount is not None
        )

        if wants_create and "create_invoice" in by_name:
            params = {}
            if name:
                params["customer_name"] = name
            if amount is not None:
                params["amount"] = amount
            steps.append(ExecutionStep(tool="create_invoice", parameters=params))
            if wants_send and "send_invoice" in by_name:
                steps.append(ExecutionStep(tool="send_invoice", parameters={"invoice_id": "$previous_result.invoice_id"}))
        else:
            invoice_id = _extract_id(query, "INV")
            steps.append(ExecutionStep(tool="send_invoice", parameters={"invoice_id": invoice_id} if invoice_id else {}))

        return ExecutionPlan(goal=query, steps=steps)

    # ---- Other invoice operations (top-ranked tool already decided by the ranker) ----
    if top_tool.tool_name in ("cancel_invoice", "get_invoice", "send_invoice_reminder"):
        invoice_id = _extract_id(query, "INV")
        return ExecutionPlan(goal=query, steps=[ExecutionStep(tool=top_tool.tool_name,
                              parameters={"invoice_id": invoice_id} if invoice_id else {})])
    if top_tool.tool_name == "list_invoices":
        return ExecutionPlan(goal=query, steps=[ExecutionStep(tool="list_invoices", parameters={})])

    # ---- Payment flows ----
    if top_tool.tool_name == "refund_payment":
        payment_id = _extract_id(query, "PAY")
        params = {"payment_id": payment_id} if payment_id else {}
        if amount is not None and "refund" in query.lower() and "payment" in query.lower():
            # only attach amount if it looks like it's describing the refund, not something else
            params["amount"] = amount
        return ExecutionPlan(goal=query, steps=[ExecutionStep(tool="refund_payment", parameters=params)])

    if top_tool.tool_name == "create_payment":
        params = {}
        if amount is not None:
            params["amount"] = amount
        if name:
            params["customer_name"] = name
        return ExecutionPlan(goal=query, steps=[ExecutionStep(tool="create_payment", parameters=params)])

    if top_tool.tool_name in ("capture_payment", "void_payment", "get_payment"):
        payment_id = _extract_id(query, "PAY")
        params = {"payment_id": payment_id} if payment_id else {}
        return ExecutionPlan(goal=query, steps=[ExecutionStep(tool=top_tool.tool_name, parameters=params)])

    # ---- Disputes ----
    if top_tool.tool_name == "get_disputes":
        params = {}
        if name:
            params["customer_name"] = name
        return ExecutionPlan(goal=query, steps=[ExecutionStep(tool="get_disputes", parameters=params)])

    if top_tool.tool_name == "create_dispute":
        payment_id = _extract_id(query, "PAY")
        params = {"payment_id": payment_id} if payment_id else {}
        return ExecutionPlan(goal=query, steps=[ExecutionStep(tool="create_dispute", parameters=params)])

    # ---- Reports ----
    if top_tool.tool_name in ("get_sales_report", "get_transaction_history", "get_payout_report"):
        params = {"period": period} if period else {}
        return ExecutionPlan(goal=query, steps=[ExecutionStep(tool=top_tool.tool_name, parameters=params)])

    # ---- Customers ----
    if top_tool.tool_name == "find_customer":
        return ExecutionPlan(goal=query, steps=[ExecutionStep(tool="find_customer", parameters={"name": name} if name else {})])

    if top_tool.tool_name == "create_customer":
        return ExecutionPlan(goal=query, steps=[ExecutionStep(tool="create_customer", parameters={"name": name} if name else {})])

    # ---- Subscriptions ----
    if top_tool.tool_name == "cancel_subscription":
        sub_id = _extract_id(query, "SUB")
        return ExecutionPlan(goal=query, steps=[ExecutionStep(tool="cancel_subscription", parameters={"subscription_id": sub_id} if sub_id else {})])

    # ---- Default: single step with best-effort parameters ----
    params = {}
    if amount is not None:
        params["amount"] = amount
    if name:
        params["customer_name"] = name
    if period:
        params["period"] = period
    return ExecutionPlan(goal=query, steps=[ExecutionStep(tool=top_tool.tool_name, parameters=params)])
