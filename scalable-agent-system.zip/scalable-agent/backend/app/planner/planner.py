"""
LLM Planner.

This is the component the whole architecture exists to protect: by the time
we get here, the tool list has already been narrowed from potentially
1000+ tools down to a handful (TOP_K_TOOLS) by the DomainRouter + Retriever
+ Ranker. The planner - real LLM or mock - is only ever shown that small
subset, and is instructed (and, for the real-LLM path, mechanically
verified) never to invent a tool name outside of it.
"""
from __future__ import annotations
import json
import re
from typing import List

from app.planner.llm_provider import get_provider
from app.planner.mock_planner import build_mock_plan
from app.ranking.ranker import RankedTool
from app.registry.schema import ExecutionPlan, ExecutionStep

SYSTEM_PROMPT_TEMPLATE = """You are the planning component of an agentic system. You will be given a \
user request and a SMALL list of tools that have already been retrieved as relevant. \
You may ONLY use tools from this list - never invent a tool name that is not listed. \
If a required parameter's value is not present in the user's message, OMIT that parameter \
rather than guessing a value.

Respond with ONLY a JSON object (no markdown fences, no prose) of this exact shape:
{{
  "goal": "<short restatement of the user's goal>",
  "steps": [
    {{"tool": "<tool_name from the list>", "parameters": {{"<param>": "<value>"}}}}
  ]
}}

If a value should come from a previous step's result, use the literal string \
"$previous_result.<field_name>" as the parameter value.

Available tools:
{tools_json}
"""


def _tools_to_prompt_json(ranked_tools: List[RankedTool]) -> str:
    payload = []
    for rt in ranked_tools:
        t = rt.tool
        payload.append({
            "tool_name": t.tool_name,
            "description": t.description,
            "required_parameters": t.required_params(),
            "optional_parameters": t.optional_params(),
            "risk_level": t.risk_level.value,
        })
    return json.dumps(payload, indent=2)


def _extract_json(text: str) -> dict | None:
    text = text.strip()
    text = re.sub(r"^```(json)?|```$", "", text, flags=re.MULTILINE).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(0))
            except json.JSONDecodeError:
                return None
        return None


def _validate_plan_against_retrieved(plan_dict: dict, ranked_tools: List[RankedTool], goal: str) -> ExecutionPlan:
    """Mechanically enforces 'the planner must never invent tools' even for
    a real LLM: any step naming a tool outside the retrieved set is dropped."""
    allowed_names = {rt.tool.tool_name for rt in ranked_tools}
    steps = []
    for raw_step in plan_dict.get("steps", []):
        tool_name = raw_step.get("tool")
        if tool_name in allowed_names:
            steps.append(ExecutionStep(tool=tool_name, parameters=raw_step.get("parameters", {})))
    return ExecutionPlan(goal=plan_dict.get("goal", goal), steps=steps)


def generate_plan(query: str, ranked_tools: List[RankedTool]) -> ExecutionPlan:
    provider = get_provider()

    if not provider.is_real_llm:
        return build_mock_plan(query, ranked_tools)

    system_prompt = SYSTEM_PROMPT_TEMPLATE.format(tools_json=_tools_to_prompt_json(ranked_tools))
    try:
        raw_response = provider.complete(system_prompt, query)
        plan_dict = _extract_json(raw_response)
        if plan_dict is None:
            # LLM returned something unparseable - fail soft to the deterministic planner
            return build_mock_plan(query, ranked_tools)
        plan = _validate_plan_against_retrieved(plan_dict, ranked_tools, query)
        if not plan.steps:
            return build_mock_plan(query, ranked_tools)
        return plan
    except Exception:
        return build_mock_plan(query, ranked_tools)
