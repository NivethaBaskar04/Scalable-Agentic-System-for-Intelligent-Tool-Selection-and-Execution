"""
System Search Tool (system_search).

Answers questions about the agent's own system rather than about PayPal
data: which tools exist, which failed recently, how many are registered,
what happened with the last request, etc. Per assignment section 14.
"""
from __future__ import annotations
import re
from typing import Any, Dict

from app.registry.store import ToolRegistry
from app.memory.state import StateStore


def system_search(query: str, registry: ToolRegistry, state: StateStore) -> Dict[str, Any]:
    q = query.lower()

    # How many tools are registered?
    if re.search(r"how many tools|total tools|number of tools", q):
        return {
            "answer_type": "tool_count",
            "total_tools": registry.count(),
            "domains": registry.domains(),
            "services": registry.services(),
        }

    # Which services are connected?
    if re.search(r"which services|connected services|what services", q):
        return {"answer_type": "services", "services": registry.services()}

    # Tools that failed recently
    if re.search(r"fail|error|broke|broken", q):
        failures = state.recent_failures(limit=10)
        return {"answer_type": "recent_failures", "failures": failures, "count": len(failures)}

    # Status of last request / execution
    if re.search(r"last request|last execution|status of my|previous request", q):
        executions = state.list_executions(limit=1)
        return {"answer_type": "last_execution", "execution": executions[0] if executions else None}

    # "What tools manage X" / "tools available for X" / "tools for X"
    domain_match = re.search(r"(?:manag\w*|available for|tools for|handle)\s+([a-z_ ]+)", q)
    if domain_match or "tools" in q:
        keyword = domain_match.group(1).strip() if domain_match else q
        keyword = keyword.rstrip("s") if keyword.endswith("s") and not keyword.endswith("ss") else keyword
        matches = registry.search_by_name_substring(keyword)
        if not matches:
            # fall back to domain-name match
            for domain in registry.domains():
                if domain.rstrip("s") in keyword or keyword in domain:
                    matches = registry.by_domain(domain)
                    break
        return {
            "answer_type": "tools_for_topic",
            "keyword": keyword,
            "matches": [
                {"tool_id": t.tool_id, "tool_name": t.tool_name, "description": t.description, "domain": t.domain}
                for t in matches[:15]
            ],
            "count": len(matches),
        }

    # Generic fallback: general system metrics
    return {
        "answer_type": "system_overview",
        "total_tools": registry.count(),
        "domains": registry.domains(),
        "metrics": state.metrics_summary(),
    }
