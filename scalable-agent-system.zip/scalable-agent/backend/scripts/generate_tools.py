"""
Generates a tool registry of a target size by combining the hand-authored
"core" PayPal tools (which are actually executable against the mock API)
with synthetically generated tools across many fictitious services/domains.

This proves the architecture can scale to 500-1000+ tools without anyone
hand-writing each tool definition, per assignment section 12.

Usage:
    python scripts/generate_tools.py --count 500
    python scripts/generate_tools.py --count 1000 --out data/tools_1000.json
"""
import argparse
import json
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.registry.core_tools import CORE_TOOLS
from app.config import TOOLS_FILE

random.seed(42)

SERVICES = [
    "paypal", "stripe_like", "shopify_like", "quickbooks_like", "netsuite_like",
    "hubspot_like", "twilio_like", "sendgrid_like", "docusign_like", "slack_like",
]

DOMAINS_BY_SERVICE = {
    "paypal": ["invoices", "payments", "customers", "subscriptions", "disputes", "reports", "payouts", "account"],
    "stripe_like": ["charges", "invoices", "customers", "subscriptions", "payouts", "reports", "disputes"],
    "shopify_like": ["orders", "products", "inventory", "customers", "reports", "fulfillment"],
    "quickbooks_like": ["invoices", "expenses", "reports", "customers", "taxes"],
    "netsuite_like": ["orders", "inventory", "reports", "customers", "invoices"],
    "hubspot_like": ["contacts", "deals", "campaigns", "reports", "customers"],
    "twilio_like": ["messages", "calls", "numbers", "reports"],
    "sendgrid_like": ["emails", "templates", "reports", "contacts"],
    "docusign_like": ["envelopes", "templates", "signatures", "reports"],
    "slack_like": ["messages", "channels", "users", "reports"],
}

OPERATIONS = ["create", "get", "update", "delete", "list", "search"]
METHOD_BY_OP = {"create": "POST", "get": "GET", "update": "PATCH", "delete": "DELETE", "list": "GET", "search": "GET"}
RISKS = ["low", "low", "low", "medium", "medium", "high"]  # weighted toward low/medium

NOUNS_BY_DOMAIN = {
    "orders": "order", "products": "product", "inventory": "inventory item",
    "contacts": "contact", "deals": "deal", "campaigns": "campaign",
    "messages": "message", "calls": "call", "numbers": "phone number",
    "emails": "email", "templates": "template", "envelopes": "envelope",
    "signatures": "signature", "channels": "channel", "users": "user",
    "expenses": "expense", "taxes": "tax record", "fulfillment": "fulfillment order",
}


def synthetic_tool(idx: int, service: str, domain: str) -> dict:
    op = random.choice(OPERATIONS)
    noun = NOUNS_BY_DOMAIN.get(domain, domain.rstrip("s"))
    tool_name = f"{op}_{noun.replace(' ', '_')}_{idx}"
    tool_id = f"{service}.{domain}.{op}.{idx}"
    risk = random.choice(RISKS)
    return {
        "tool_id": tool_id,
        "tool_name": tool_name,
        "service": service,
        "domain": domain,
        "operation": op,
        "description": f"{op.capitalize()}s a {noun} via the {service} {domain} API (synthetic tool #{idx}, for scale testing).",
        "method": METHOD_BY_OP[op],
        "endpoint": f"/{service}/{domain}/{idx}",
        "input_schema": [
            {"name": "id", "type": "string", "required": op not in ("create", "list"), "description": f"{noun} identifier"},
        ] + ([{"name": "payload", "type": "string", "required": True, "description": "Generic payload"}] if op in ("create", "update") else []),
        "output_schema": {"status": "string"},
        "required_auth": True,
        "risk_level": risk,
        "tags": [domain, op, service, noun.split(" ")[0]],
        "version": "1.0",
        "dependencies": [],
    }


def _jsonable(tool_dict: dict) -> dict:
    """CORE_TOOLS stores input_schema as ParamSchema pydantic instances
    (for convenient re-use by app.registry.core_tools.build_core_tools);
    convert them to plain dicts for JSON serialization here."""
    d = dict(tool_dict)
    d["input_schema"] = [
        p.model_dump() if hasattr(p, "model_dump") else p
        for p in d.get("input_schema", [])
    ]
    return d


def generate(count: int) -> list[dict]:
    tools = [_jsonable(t) for t in CORE_TOOLS]
    core_count = len(tools)
    remaining = max(0, count - core_count)

    idx = 0
    while len(tools) < count:
        service = random.choice(SERVICES)
        domain = random.choice(DOMAINS_BY_SERVICE[service])
        tools.append(synthetic_tool(idx, service, domain))
        idx += 1

    return tools[:count] if count >= core_count else tools


def main():
    parser = argparse.ArgumentParser(description="Generate a scaled tool registry")
    parser.add_argument("--count", type=int, default=100, help="Total number of tools to generate (including core tools)")
    parser.add_argument("--out", type=str, default=str(TOOLS_FILE), help="Output JSON path")
    args = parser.parse_args()

    tools = generate(args.count)
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(tools, f, indent=2)

    print(f"Generated {len(tools)} tools -> {out_path}")
    print(f"  Core (executable) tools: {len(CORE_TOOLS)}")
    print(f"  Synthetic (benchmark) tools: {max(0, len(tools) - len(CORE_TOOLS))}")


if __name__ == "__main__":
    main()
