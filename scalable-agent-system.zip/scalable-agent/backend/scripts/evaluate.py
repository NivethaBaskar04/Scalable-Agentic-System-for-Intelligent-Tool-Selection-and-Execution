"""
Evaluation script (assignment section 25).

Runs a battery of user queries through the real pipeline and reports:
- which tool(s) were selected
- whether required parameters were correctly extracted
- task completion status
- latency
- how many tools were exposed to the planner vs. how many exist in total

Also produces the BASELINE vs PROPOSED comparison: "LLM receives all N
tools" vs "LLM receives only the top-K retrieved/ranked tools" - measured
here as prompt size (tokens/characters) sent to the planner, which is the
direct, measurable proxy for the context-bloat problem this whole
architecture exists to solve.

Usage:
    python scripts/evaluate.py
    python scripts/evaluate.py --json report.json
"""
import argparse
import asyncio
import json
import logging
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
logging.disable(logging.CRITICAL)  # keep evaluation output clean

from app.agents.orchestrator import AgentOrchestrator
from app.registry.store import registry
from app.memory.state import StateStore
from app.planner.planner import _tools_to_prompt_json
from app.ranking.ranker import RankedTool


TEST_QUERIES = [
    {"query": "Send an invoice for $50", "expected_tool": "create_invoice", "confirm": True},
    {"query": "Create invoice for John for $120", "expected_tool": "create_invoice", "confirm": True},
    {"query": "Refund payment PAY-SEED1", "expected_tool": "refund_payment", "confirm": True},
    {"query": "What were my sales last month?", "expected_tool": "get_sales_report", "confirm": False},
    {"query": "Is there an open dispute for user_123?", "expected_tool": "get_disputes", "confirm": False},
    {"query": "Get customer information for CUST-1", "expected_tool": "get_customer", "confirm": False},
    {"query": "Cancel subscription SUB-1", "expected_tool": "cancel_subscription", "confirm": True},
    {"query": "Create payment for $99", "expected_tool": "create_payment", "confirm": True},
    {"query": "Get transaction history for last month", "expected_tool": "get_transaction_history", "confirm": False},
    {"query": "How do disputes work?", "expected_tool": "rag_search", "confirm": False},
    {"query": "What tools manage invoices?", "expected_tool": "system_search", "confirm": False},
    {"query": "What was my last request status?", "expected_tool": "system_search", "confirm": False},
    {"query": "What is my current balance?", "expected_tool": "get_balance", "confirm": False},
    {"query": "Show me merchant information", "expected_tool": "get_merchant_information", "confirm": False},
    {"query": "List all my invoices", "expected_tool": "list_invoices", "confirm": False},
    {"query": "List payments", "expected_tool": "list_payments", "confirm": False},
    {"query": "Cancel invoice INV-1", "expected_tool": "cancel_invoice", "confirm": True},
    {"query": "How does invoicing work?", "expected_tool": "rag_search", "confirm": False},
    {"query": "How many tools are registered?", "expected_tool": "system_search", "confirm": False},
    {"query": "Void payment PAY-SEED1", "expected_tool": "void_payment", "confirm": True},
    {"query": "Get payout report for last month", "expected_tool": "get_payout_report", "confirm": False},
    {"query": "List my customers", "expected_tool": "list_customers", "confirm": False},
]


async def run_proposed(orch: AgentOrchestrator, item: dict) -> dict:
    start = time.perf_counter()
    result = await orch.handle_query(item["query"], confirm=item.get("confirm", False))
    latency_ms = (time.perf_counter() - start) * 1000

    selected_tools = [s["tool_name"] for s in result.steps] or \
        [result.plan.get("steps", [{}])[0].get("tool")] if result.plan.get("steps") else []
    tool_correct = item["expected_tool"] in selected_tools

    return {
        "query": item["query"],
        "expected_tool": item["expected_tool"],
        "selected_tools": selected_tools,
        "tool_selection_correct": tool_correct,
        "status": result.status,
        "task_completed": result.status == "success",
        "latency_ms": round(latency_ms, 2),
        "tools_retrieved_count": len(result.tools_retrieved),
        "total_tools_available": result.total_tools_available,
    }


def estimate_baseline_prompt_size(all_tools_count: int, ranked_sample: list) -> dict:
    """
    Estimates prompt size if the planner were shown ALL tools vs. only the
    top-K ranked subset, using the actual JSON serialization the planner
    would send (see app/planner/planner.py::_tools_to_prompt_json).
    """
    if not ranked_sample:
        return {"baseline_chars": 0, "proposed_chars": 0}

    proposed_json = _tools_to_prompt_json(ranked_sample)
    avg_chars_per_tool = len(proposed_json) / max(len(ranked_sample), 1)
    baseline_chars_estimate = int(avg_chars_per_tool * all_tools_count)

    return {
        "proposed_chars": len(proposed_json),
        "proposed_tool_count": len(ranked_sample),
        "baseline_chars_estimate": baseline_chars_estimate,
        "baseline_tool_count": all_tools_count,
        "reduction_factor": round(baseline_chars_estimate / max(len(proposed_json), 1), 1),
    }


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--json", type=str, default=None, help="Write full report to this JSON file")
    args = parser.parse_args()

    # Use an isolated in-memory-like state DB so eval runs don't skew production stats
    state = StateStore(db_path=":memory:") if False else StateStore()  # sqlite3 :memory: not shareable across conns; use real file
    orch = AgentOrchestrator(registry, state)

    print(f"Running {len(TEST_QUERIES)} evaluation queries against a registry of {registry.count()} tools...\n")

    results = []
    for item in TEST_QUERIES:
        r = await run_proposed(orch, item)
        results.append(r)
        status_icon = "PASS" if r["tool_selection_correct"] else "FAIL"
        print(f"[{status_icon}] {r['query']!r:55s} -> {r['selected_tools']} "
              f"({r['latency_ms']:.1f}ms, {r['tools_retrieved_count']}/{r['total_tools_available']} tools shown)")

    total = len(results)
    tool_accuracy = sum(1 for r in results if r["tool_selection_correct"]) / total
    completion_rate = sum(1 for r in results if r["task_completed"] or r["status"] == "needs_clarification") / total
    avg_latency = sum(r["latency_ms"] for r in results) / total
    avg_tools_shown = sum(r["tools_retrieved_count"] for r in results) / total

    print("\n" + "=" * 70)
    print("SUMMARY")
    print("=" * 70)
    print(f"Tool selection accuracy : {tool_accuracy*100:.1f}%")
    print(f"Task completion rate     : {completion_rate*100:.1f}%  (includes correct clarification asks)")
    print(f"Average latency          : {avg_latency:.1f} ms")
    print(f"Average tools shown to planner : {avg_tools_shown:.1f} (of {registry.count()} total registered)")

    # Baseline vs proposed prompt-size comparison, using the last query's ranked set as a sample
    sample_query = TEST_QUERIES[0]["query"]
    domain_scores = orch.domain_router.route(sample_query, top_k=3)
    top_domain = domain_scores[0][0] if domain_scores else None
    pool = []
    for d, _ in domain_scores:
        pool.extend(registry.by_domain(d))
    retrieved = orch.retriever.retrieve(sample_query, top_k=15, candidate_pool=pool)
    from app.ranking.ranker import rank_tools
    ranked = rank_tools(sample_query, retrieved, domain_scores, state)[:5]
    comparison = estimate_baseline_prompt_size(registry.count(), ranked)

    print("\n" + "=" * 70)
    print("BASELINE (all tools) vs PROPOSED (top-K retrieved) COMPARISON")
    print("=" * 70)
    print(f"Baseline:  ~{comparison['baseline_chars_estimate']:,} chars sent to LLM "
          f"for all {comparison['baseline_tool_count']} tools")
    print(f"Proposed:  {comparison['proposed_chars']:,} chars sent to LLM "
          f"for top {comparison['proposed_tool_count']} tools")
    print(f"Reduction: {comparison['reduction_factor']}x smaller prompt")

    report = {
        "results": results,
        "summary": {
            "tool_selection_accuracy": tool_accuracy,
            "task_completion_rate": completion_rate,
            "avg_latency_ms": avg_latency,
            "avg_tools_shown": avg_tools_shown,
            "total_tools_registered": registry.count(),
        },
        "baseline_vs_proposed": comparison,
    }

    if args.json:
        with open(args.json, "w") as f:
            json.dump(report, f, indent=2, default=str)
        print(f"\nFull report written to {args.json}")


if __name__ == "__main__":
    asyncio.run(main())
