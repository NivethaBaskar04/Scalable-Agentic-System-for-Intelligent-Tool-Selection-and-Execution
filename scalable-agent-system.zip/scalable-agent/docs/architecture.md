# Architecture

## 1. High-level pipeline

```mermaid
flowchart TD
    U[User message] --> IR[Intent Analysis + Domain Router]
    IR --> SR[Semantic Tool Retriever]
    SR --> RK[Tool Ranker]
    RK --> SUB[Relevant Tool Subset - top K]
    SUB --> PL[LLM Planner]
    PL --> VAL[Parameter Validator]
    VAL --> EX[Execution Engine]
    EX --> RV[Result Validator]
    RV --> RESP[Natural Language Response]

    subgraph Registry
      REG[(Tool Registry - N tools)]
    end
    REG -.metadata.-> IR
    REG -.candidate pool.-> SR
    REG -.risk / deps.-> VAL
```

The LLM/planner (`PL`) never sees `REG` directly - it only ever receives
`SUB`, which is bounded by `TOP_K_TOOLS` regardless of how large `REG` grows.
This is the single design decision that makes the system scale from 10 to
1000+ tools without a proportional increase in planner context.

## 2. Tool discovery pipeline

```mermaid
flowchart LR
    Q[Query] --> DR[Domain Router\nTF-IDF over per-domain\ntool-text profiles]
    DR --> CP[Candidate Pool\ntools in top domains\n+ knowledge/system fallback]
    CP --> RET[Retriever\nTF-IDF cosine similarity\nquery vs tool text]
    RET --> CAND["Candidates (RETRIEVAL_CANDIDATE_K)"]
    CAND --> RANK[Ranker\nweighted blend of signals]
    RANK --> TOPK["Top-K tools (TOP_K_TOOLS)"]
```

Ranker signal weights (`app/config.py::RANK_WEIGHTS`):

```
final_score = 0.45 * semantic_similarity
            + 0.20 * domain_match
            + 0.15 * parameter_match
            + 0.10 * historical_success
            + 0.10 * reliability
```

`domain_match` is proportional to the domain router's own score for that
tool's domain (normalized against the winning domain), not a flat binary -
this keeps a strong runner-up domain's tools (e.g. "knowledge" for a
conceptual question inside a domain-heavy query) competitive rather than
being excluded outright.

## 3. Agent request state machine

```mermaid
stateDiagram-v2
    [*] --> RoutingDomain
    RoutingDomain --> Retrieving
    Retrieving --> Ranking
    Ranking --> NoToolsFound: empty candidate set
    Ranking --> Planning
    Planning --> NoPlan: planner returns zero steps
    Planning --> NeedsConfirmation: any step is HIGH risk
    NeedsConfirmation --> Executing: user confirms
    NeedsConfirmation --> [*]: user cancels
    Planning --> Executing: no high-risk steps
    Executing --> NeedsClarification: required parameter missing
    Executing --> Failed: tool/API error after retries
    Executing --> Success: all steps completed
    NoToolsFound --> [*]
    NoPlan --> [*]
    NeedsClarification --> [*]
    Failed --> [*]
    Success --> [*]
```

## 4. Tool execution flow (with output passing)

```mermaid
sequenceDiagram
    participant P as Planner
    participant V as Validator
    participant E as Execution Engine
    participant M as Mock PayPal API (SQLite)

    P->>E: plan.steps = [create_invoice, send_invoice]
    E->>V: validate(create_invoice, {amount: 50})
    V-->>E: valid
    E->>M: POST /paypal/invoices {amount: 50}
    M-->>E: {invoice_id: "INV-123", status: "DRAFT"}
    E->>E: store step_results[0] = {invoice_id: "INV-123", ...}
    E->>V: validate(send_invoice, {invoice_id: "$previous_result.invoice_id"})
    E->>E: resolve reference -> invoice_id = "INV-123"
    V-->>E: valid
    E->>M: POST /paypal/invoices/INV-123/send
    M-->>E: {invoice_id: "INV-123", status: "SENT"}
    E-->>P: ExecutionTrace(status=success, steps=[...])
```

Retries with exponential backoff wrap each individual tool call
(`MAX_RETRIES`, `RETRY_BASE_DELAY_SECONDS`); a step's failure after
exhausting retries stops the plan but preserves every prior successful
step's result in the trace.

## 5. RAG pipeline

```mermaid
flowchart LR
    Q[User question] --> RS["rag_search tool"]
    RS --> CH[Markdown docs -> paragraph chunks]
    CH --> VEC[TF-IDF vectors]
    Q --> QV[Query vector]
    VEC --> SIM[Cosine similarity]
    QV --> SIM
    SIM --> TOPP["Top-K passages + source + score"]
```

## 6. System search architecture

`system_search` answers meta-questions about the agent itself rather than
about PayPal data. It queries three internal sources directly (no vector
search needed - these are small, structured stores):

```mermaid
flowchart TD
    Q[Meta question] --> SS[system_search]
    SS --> REG[(Tool Registry)]
    SS --> LOG[(Execution/step_results table)]
    SS --> META[Domains / services list]
    REG --> ANS[Answer: tool counts, matching tools]
    LOG --> ANS2[Answer: last execution, recent failures]
    META --> ANS3[Answer: connected services]
```

## 7. Scalability architecture

```mermaid
flowchart TD
    subgraph "Registry growth: 10 -> 50 -> 100 -> 500 -> 1000+"
      R1[10 tools] --> R2[50 tools] --> R3[100 tools] --> R4[500 tools] --> R5[1000+ tools]
    end
    R1 & R2 & R3 & R4 & R5 --> CONST["Domain Router + Retriever + Ranker\n(all metadata/TF-IDF driven,\nno registry-size-dependent logic)"]
    CONST --> FLAT["Tools shown to planner: constant (TOP_K_TOOLS)"]
```

`scripts/benchmark.py` measures this directly. Representative run
(`data/benchmark_results.json`):

| Registry size | Avg total latency | Avg tools shown to planner |
|---|---|---|
| 38 (core only) | ~14 ms | 5.0 |
| 50 | ~9 ms | 5.0 |
| 100 | ~10 ms | 5.0 |
| 500 | ~10 ms | 5.0 |
| 1000 | ~11 ms | 5.0 |

Retrieval/ranking latency grows sub-linearly (TF-IDF cosine similarity over
a few hundred rows is still sub-millisecond), and the number of tools shown
to the planner is flat by construction - it is a hard `TOP_K_TOOLS` cap
applied after ranking, not an emergent property of the data.

## Component reference

| Component | File | Responsibility |
|---|---|---|
| Tool schema | `app/registry/schema.py` | Canonical tool shape (Pydantic) |
| Core tools | `app/registry/core_tools.py` | ~38 hand-authored, executable PayPal-like tools |
| Tool generator | `scripts/generate_tools.py` | Synthesizes bulk tools for scale testing |
| Registry store | `app/registry/store.py` | Load/search tools by metadata (no hardcoded routing) |
| Domain router | `app/domain_router.py` | TF-IDF classification of query -> domain(s) |
| Retriever | `app/retrieval/tfidf_retriever.py` | query -> vector -> cosine similarity -> candidates |
| Ranker | `app/ranking/ranker.py` | Weighted multi-signal re-scoring |
| LLM provider | `app/planner/llm_provider.py` | Anthropic / OpenAI / mock abstraction |
| Mock planner | `app/planner/mock_planner.py` | Deterministic planner used with no API key |
| Planner | `app/planner/planner.py` | Orchestrates LLM/mock planning, enforces "never invent a tool" |
| Validator | `app/validation/validator.py` | Required/type/enum/range checks before execution |
| Execution engine | `app/executor/engine.py` | Retries, backoff, timeout, output-passing |
| Mock PayPal API | `app/mock_paypal.py` | Stateful FastAPI + SQLite simulation |
| RAG engine | `app/rag/rag_engine.py` | TF-IDF search over Markdown knowledge base |
| System search | `app/system_search/search.py` | Meta-queries over registry/logs |
| State store | `app/memory/state.py` | SQLite-backed conversations/executions/tool stats |
| Orchestrator | `app/agents/orchestrator.py` | Wires every stage into one request handler |
| Observability | `app/observability/tracer.py` | Structured logs + per-stage trace |
