# API Reference

Base URL: `http://localhost:8000`

All agentic-system endpoints are under `/api`. The mock PayPal API is
mounted at `/paypal` (browsable interactively at `/docs`).

## POST /api/chat

Runs a user message through the full pipeline.

**Request**
```json
{ "message": "Send an invoice for $50", "conversation_id": null, "confirm": false }
```

**Response** (abridged)
```json
{
  "domain": "invoices",
  "total_tools_available": 100,
  "tools_retrieved": [ { "tool_name": "create_invoice", "final_score": 0.56, ... } ],
  "plan": { "goal": "...", "steps": [ { "tool": "create_invoice", "parameters": {"amount": 50} } ] },
  "trace": [ { "stage": "domain_router", "latency_ms": 0.8, "detail": {...} }, ... ],
  "status": "success",
  "message": "Created invoice INV-123. sent invoice INV-123.",
  "requires_confirmation": false,
  "steps": [ { "tool_name": "create_invoice", "success": true, "result": {...} } ]
}
```

If a step involves a HIGH risk tool (refunds, deletions, payouts, etc.),
`status` will be `"needs_confirmation"` and `requires_confirmation: true`.
Re-send the same message with `"confirm": true` to proceed.

## GET /api/tools

Lists tools in the registry. Query params: `domain`, `service`, `limit`, `offset`.

## GET /api/tools/{tool_id}

Full definition of a single tool.

## POST /api/tools/search

Runs the semantic retriever directly (bypasses domain routing/ranking).
```json
{ "query": "cancel a subscription", "top_k": 5 }
```

## GET /api/domains

Lists every domain and its tool count.

## POST /api/rag/search

Searches the knowledge base.
```json
{ "query": "how do refunds work" }
```

## POST /api/system/search

Queries the agent's own system (registry, execution history).
```json
{ "query": "what tools manage invoices" }
```

## GET /api/executions

Recent executions (most recent first).

## GET /api/executions/{execution_id}

Full detail (plan + per-step results) for one execution.

## GET /api/metrics

Aggregate system metrics: total tools, domains, services, success rate,
average latency, RAG index size, active LLM provider.

## GET /api/health

Basic liveness check.

## POST /api/admin/reload-registry

Reloads `data/tools.json` from disk and rebuilds the domain router and
retriever indexes - use after running `scripts/generate_tools.py` to change
registry size without restarting the server.

## Mock PayPal API (`/paypal/*`)

Full CRUD-style endpoints for invoices, payments, customers, subscriptions,
disputes, reports, payouts, and account/auth - see `/docs` for the complete,
interactive list. All state is persisted in `data/mock_paypal.sqlite3`.
