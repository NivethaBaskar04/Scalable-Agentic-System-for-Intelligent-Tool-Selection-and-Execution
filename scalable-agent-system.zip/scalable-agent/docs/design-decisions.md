# Design Justification

## Why hierarchical tool retrieval instead of exposing every tool?

LLMs degrade measurably as the number of tool definitions in context grows:
wrong tool selection, hallucinated parameters, and slower/more expensive
calls. The fix isn't a bigger model or a longer prompt - it's to never put
the full tool list in front of the model in the first place. A human support
agent doesn't memorize every API in the company; they know which *team*
handles a request, then look up the specific action. This system mirrors
that: domain routing narrows "which part of the system", retrieval narrows
"which specific tools", and only the survivors reach the planner.

## Why semantic search (retrieval) instead of keyword rules?

A hardcoded `if "invoice" in query: use invoice_tool` breaks the moment
phrasing varies ("bill them", "send them a request for payment") or the
registry grows past what a human can keep in an if/else chain. Semantic
(vector) retrieval generalizes to paraphrases and scales by adding
embeddings/rows, not by adding code branches - which is the explicit
requirement in the assignment ("do NOT hardcode routing logic").

## Why TF-IDF instead of sentence-transformers + FAISS/Chroma?

The assignment's preferred stack is sentence-transformers + FAISS/Chroma,
and the codebase is structured so that's a drop-in swap (`BaseRetriever` in
`app/retrieval/tfidf_retriever.py` is the interface; a
`SentenceTransformerRetriever` implementing the same `retrieve()` signature
would need zero changes anywhere else). This project ships TF-IDF by default
because:
- It requires no model download at first run, which matters for a demo that
  has to work offline / without internet access to a model hub.
- It's fully deterministic, which keeps the evaluation script's accuracy
  numbers reproducible run to run.
- At the scale demonstrated here (up to ~1000 tool descriptions), TF-IDF's
  retrieval quality is very close to a small sentence embedding model, and
  its latency is effectively free (sub-millisecond).

At a much larger scale (tens of thousands of tools, or tools with more
semantically subtle descriptions), swapping in real embeddings + an ANN
index (FAISS/Chroma) would improve recall on paraphrased queries and is the
recommended upgrade path - the interface is already there for it.

## Why top-K retrieval, and why re-rank afterward?

Retrieval alone (nearest-neighbor by text similarity) is a good filter but
an imperfect ranker: it can't see whether the query's extractable entities
(an amount, an ID) actually match a candidate tool's required parameters,
or whether a tool has a track record of failing. So retrieval pulls a wider
candidate pool (`RETRIEVAL_CANDIDATE_K`, default 15) and a second ranking
pass re-scores that pool with a weighted blend of signals before truncating
to the much smaller `TOP_K_TOOLS` (default 5) that the planner actually
sees. This two-stage retrieve-then-rank design is standard in search/IR
systems for the same reason: the cheap stage (vector similarity) narrows a
huge space fast; the more expensive/precise stage (multi-signal ranking)
only has to run over a small pool.

## Why these five ranking signals, and why those weights?

- **Semantic similarity (0.45)** - the dominant signal; text relevance is
  still the strongest predictor of "is this the right tool."
- **Domain match (0.20)** - a tool in the query's routed domain is
  structurally more likely to be right than one that happens to share
  vocabulary but lives elsewhere; implemented as a graded score
  (proportional to the router's own confidence per domain) rather than a
  flat binary, so a strong runner-up domain isn't wrongly zeroed out.
- **Parameter match (0.15)** - a cheap prior for whether the query actually
  contains what this tool needs (an amount, an ID-shaped token, etc.)
  before any real extraction happens.
- **Historical success (0.10)** and **reliability (0.10)** - tools that have
  actually worked reliably in this deployment should be preferred over
  similarly-scored tools with a worse track record; this is the hook that
  lets the system self-improve slightly over time without retraining
  anything.

All five weights are environment-configurable (`app/config.py` /
`.env`), because the right balance is a judgment call that depends on how
trustworthy the domain router is for a given tool catalog, how noisy
historical data is, etc. - not something to hardcode as a universal
constant.

## Why not expose all tools and just ask the LLM to pick from a JSON array?

That's the literal thing this architecture exists to avoid, and it is also
the explicit BASELINE this project benchmarks against
(`scripts/evaluate.py`). At 100 registered tools, sending the full catalog
costs roughly 20x more prompt characters than sending the top-5 retrieved
subset (measured, not estimated, in the evaluation report) - and that ratio
gets worse, not better, as the catalog grows toward 500-1000 tools, while
the proposed architecture's prompt size stays flat.

## Why a custom state machine instead of LangGraph?

LangGraph is a legitimate choice here, and nothing in this design
architecturally excludes it - `AgentOrchestrator.handle_query` already *is*
a linear state machine (domain routing -> retrieval -> ranking -> planning
-> validation -> execution -> response) with well-defined transitions
(see `docs/architecture.md`'s state diagram), which maps directly onto a
LangGraph graph if desired. This project uses a hand-rolled orchestrator
instead because:
- The control flow here is fundamentally linear with a few early exits
  (no tools found, no plan, needs confirmation, needs clarification) - not
  a complex branching/looping agent graph - so a graph framework's main
  value-adds (cyclic flows, sub-graph composition, built-in checkpointing)
  aren't needed yet.
- Fewer dependencies for a project whose main deliverable is *the retrieval
  architecture*, not the orchestration framework.
- Full control over exactly what's traced/logged at each step for the
  observability requirements (section 17), without learning a framework's
  own tracing model first.

If the agent grows real branching/looping behavior (e.g., multi-turn
negotiation over which of several ambiguous tools to use, or parallel
sub-agents per domain), migrating this orchestrator's stages into LangGraph
nodes is a natural next step and wouldn't require changing any of the
underlying registry/retrieval/ranking/execution modules.

## Why FastAPI?

Async-native (needed for the execution engine's concurrent/retrying HTTP
calls to the mock API), automatic OpenAPI docs (useful for both the real
`/api` surface and for browsing the mock PayPal endpoints at `/docs`),
Pydantic-native request/response validation, and minimal boilerplate
compared to Flask+extensions for the same feature set.

## Why SQLite initially, and how does this migrate to Postgres/Redis/Kafka/K8s?

SQLite requires no separate service to run the demo, which matters for the
"must run locally with no paid dependencies" requirement (section 21/30).
Every data-access method in `app/memory/state.py` and `app/mock_paypal.py`
is a small, self-contained SQL statement behind a narrow interface
(`StateStore`), which is exactly what makes the migration path
straightforward rather than a rewrite:

- **PostgreSQL**: swap the `sqlite3` connection for `asyncpg`/`psycopg` in
  `StateStore._conn()` and `mock_paypal.py`'s connection helper; the SQL is
  already close to standard SQL (minor dialect differences like
  `AUTOINCREMENT` -> `SERIAL`). Needed once multiple server processes must
  share state (SQLite's single-writer model doesn't horizontally scale).
- **Redis**: a natural fit for the ranker's `historical_success` /
  `reliability` counters (`tool_stats`), which are simple counters/gauges
  read on every request - moving just that table to Redis removes it from
  the request-latency-critical path without touching the rest of the schema.
- **Kafka**: once execution logging (`step_results`) needs to feed
  downstream consumers (analytics, alerting on failure spikes) rather than
  just being queried directly, emit each `record_step_result` call as an
  event instead of / in addition to a direct SQL write.
- **Kubernetes / distributed workers**: the execution engine already treats
  each tool call as an independent async unit of work; running many
  orchestrator instances behind a load balancer requires only that
  `StateStore` and the tool registry move to shared services (Postgres +
  Redis, per above) instead of local SQLite files, since the application
  layer itself holds no in-process state that isn't already re-derivable
  from the registry file or the database.

## Why use both hand-authored core tools AND a synthetic generator?

Hand-authoring every one of 500-1000 tools would take longer than the
project itself and wouldn't prove anything the assignment cares about -
what matters is that retrieval/ranking/planning latency and prompt size
stay flat as the *registry* grows, not that every one of those tools is
individually meaningful. So this project hand-authors a realistic ~38-tool
PayPal-like surface that is fully executable end-to-end against a stateful
mock API (this is what the chat demo actually uses), and layers a generator
(`scripts/generate_tools.py`) on top that produces however many additional
inert-but-realistically-shaped tools are needed to stress-test scale,
without anyone hand-writing tool #501.

## Trade-offs and honest limitations

- The **mock planner** (used when no LLM API key is configured) is
  rule-based, not a language model - it's good enough to demo the full
  pipeline deterministically and for free, but it will miss phrasings a
  real LLM would handle. Plugging in `LLM_PROVIDER=anthropic` with a real
  key routes the same retrieved-tool-subset through an actual model instead.
- **TF-IDF retrieval** relies on shared vocabulary between the query and a
  tool's description/tags; two genuinely synonymous phrasings with zero
  shared words (rare in practice, given descriptions are written in plain
  language) would retrieve worse than a real embedding model. This is the
  clearest, most isolated upgrade path if evaluation on a broader query set
  showed a real accuracy gap.
- **Risk-based confirmation** currently gates on a tool's static
  `risk_level` rather than the specific parameters of a call (e.g. a $5
  refund and a $5,000 refund are both flagged the same way). A refinement
  would score risk as a function of both the tool and its resolved
  parameters.
